import React, { useState } from 'react';
import { Scale, BookOpen, FolderOpen, Settings, HelpCircle, ChevronDown, User, Bell, Search } from 'lucide-react';

interface TopNavProps {
  view: string;
  onNavigate: (view: string) => void;
  onSearch: (q: string) => void;
  searchQuery: string;
}

export default function TopNav({ view, onNavigate, onSearch, searchQuery }: TopNavProps) {
  const [inputVal, setInputVal] = useState(searchQuery);
  const [userOpen, setUserOpen] = useState(false);

  const handleKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && inputVal.trim()) {
      onSearch(inputVal.trim());
    }
  };

  return (
    <header className="h-12 bg-white border-b border-gray-200 flex items-center px-4 gap-4 z-50 relative flex-shrink-0" style={{ borderColor: '#e5e0d8' }}>
      {/* Logo */}
      <button
        onClick={() => onNavigate('home')}
        className="flex items-center gap-2 flex-shrink-0"
      >
        <div className="w-7 h-7 rounded flex items-center justify-center" style={{ background: '#1a1a2e' }}>
          <Scale size={14} className="text-white" />
        </div>
        <span className="font-semibold text-sm tracking-tight" style={{ color: '#1a1a2e', fontFamily: 'Crimson Pro, serif', fontSize: '1.05rem' }}>
          midpage
        </span>
      </button>

      <div className="w-px h-5 bg-gray-200 flex-shrink-0" />

      {/* Nav links */}
      <nav className="flex items-center gap-1 flex-shrink-0">
        <button
          onClick={() => onNavigate('research')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all ${
            view === 'research'
              ? 'bg-amber-50 text-amber-800'
              : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
          }`}
        >
          <BookOpen size={13} />
          Research
        </button>
        <button
          onClick={() => onNavigate('search')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all ${
            (view === 'search' || view === 'case')
              ? 'bg-amber-50 text-amber-800'
              : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
          }`}
        >
          <Search size={13} />
          Cases
        </button>
        <button
          className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-all"
        >
          <FolderOpen size={13} />
          Library
        </button>
      </nav>

      {/* Search bar (mini) */}
      {(view === 'search' || view === 'case') && (
        <div className="flex-1 max-w-xl">
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={inputVal}
              onChange={e => setInputVal(e.target.value)}
              onKeyDown={handleKey}
              placeholder="Search cases, citations, legal concepts..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-gray-50 border rounded-md focus:bg-white transition-all search-input"
              style={{ borderColor: '#d4c9b8', outline: 'none' }}
            />
          </div>
        </div>
      )}

      <div className="ml-auto flex items-center gap-2">
        <button className="p-1.5 rounded hover:bg-gray-100 text-gray-500 transition-all">
          <HelpCircle size={15} />
        </button>
        <button className="p-1.5 rounded hover:bg-gray-100 text-gray-500 transition-all">
          <Bell size={15} />
        </button>
        <div className="relative">
          <button
            onClick={() => setUserOpen(!userOpen)}
            className="flex items-center gap-1.5 pl-1.5 pr-2 py-1 rounded hover:bg-gray-100 transition-all"
          >
            <div className="w-6 h-6 rounded-full judge-avatar flex items-center justify-center text-white text-xs font-semibold">
              J
            </div>
            <ChevronDown size={12} className="text-gray-400" />
          </button>
          {userOpen && (
            <div className="absolute right-0 top-full mt-1 w-48 bg-white rounded-lg shadow-lg border py-1 z-50" style={{ borderColor: '#e5e0d8' }}>
              <div className="px-3 py-2 border-b" style={{ borderColor: '#e5e0d8' }}>
                <p className="text-xs font-medium text-gray-900">Jane Attorney</p>
                <p className="text-xs text-gray-500">jane@lawfirm.com</p>
              </div>
              <button className="w-full text-left px-3 py-1.5 text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                <User size={12} /> Account
              </button>
              <button className="w-full text-left px-3 py-1.5 text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                <Settings size={12} /> Settings
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
