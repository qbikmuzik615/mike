import { useState } from 'react';
import { Search, Scale, Zap, Shield, ArrowRight, Sparkles, FileText, Users, TrendingUp } from 'lucide-react';
import { SAMPLE_QUERIES } from '../data/cases';

interface HomePageProps {
  onSearch: (q: string) => void;
  onResearch: (q: string) => void;
}

export default function HomePage({ onSearch, onResearch }: HomePageProps) {
  const [query, setQuery] = useState('');
  const [mode, setMode] = useState<'search' | 'research'>('research');

  const handleSubmit = (q: string = query) => {
    if (!q.trim()) return;
    if (mode === 'research') onResearch(q.trim());
    else onSearch(q.trim());
  };

  return (
    <div className="flex-1 overflow-auto" style={{ background: '#f8f7f4' }}>
      {/* Hero */}
      <div className="max-w-3xl mx-auto px-6 pt-16 pb-8">
        {/* Badge */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium border"
            style={{ background: '#fef9f0', borderColor: '#e8d5b0', color: '#8b6f4e' }}>
            <Sparkles size={11} />
            AI-Powered Legal Research
          </div>
        </div>

        {/* Heading */}
        <h1 className="text-center font-serif mb-4" style={{ fontSize: '2.75rem', lineHeight: 1.15, color: '#1a1a2e', fontFamily: 'Crimson Pro, serif', fontWeight: 500 }}>
          Legal research that<br />
          <span style={{ color: '#8b6f4e' }}>thinks with you</span>
        </h1>
        <p className="text-center text-sm mb-8 max-w-lg mx-auto" style={{ color: '#6b5a4a', lineHeight: 1.7 }}>
          Find case law, analyze precedents, and draft legal arguments with AI that understands context, citations, and the nuances of the law.
        </p>

        {/* Search box */}
        <div className="rounded-xl shadow-sm border overflow-hidden" style={{ background: 'white', borderColor: '#d4c9b8' }}>
          {/* Mode toggle */}
          <div className="flex border-b" style={{ borderColor: '#e5e0d8' }}>
            <button
              onClick={() => setMode('research')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium transition-all ${
                mode === 'research'
                  ? 'border-b-2 -mb-px'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
              style={mode === 'research' ? { borderBottomColor: '#8b6f4e', color: '#5a3e2b' } : {}}
            >
              <Sparkles size={12} />
              AI Research
            </button>
            <button
              onClick={() => setMode('search')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium transition-all ${
                mode === 'search'
                  ? 'border-b-2 -mb-px'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
              style={mode === 'search' ? { borderBottomColor: '#8b6f4e', color: '#5a3e2b' } : {}}
            >
              <Search size={12} />
              Case Search
            </button>
          </div>

          <div className="p-3">
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={query}
                  onChange={e => setQuery(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSubmit()}
                  placeholder={
                    mode === 'research'
                      ? 'Ask a legal question, e.g. "What is the pleading standard for federal complaints?"'
                      : 'Search cases, citations, or legal concepts...'
                  }
                  className="w-full pl-9 pr-4 py-2.5 text-sm rounded-lg border transition-all search-input"
                  style={{ borderColor: '#d4c9b8', outline: 'none', background: '#fafaf8' }}
                  autoFocus
                />
              </div>
              <button
                onClick={() => handleSubmit()}
                className="px-4 py-2.5 rounded-lg text-sm font-medium text-white flex items-center gap-2 hover:opacity-90 transition-all"
                style={{ background: '#1a1a2e' }}
              >
                {mode === 'research' ? <Sparkles size={14} /> : <Search size={14} />}
                {mode === 'research' ? 'Research' : 'Search'}
              </button>
            </div>
          </div>

          {/* Suggestions */}
          <div className="px-3 pb-3 flex flex-wrap gap-1.5">
            {SAMPLE_QUERIES.slice(0, 4).map(q => (
              <button
                key={q}
                onClick={() => { setQuery(q); handleSubmit(q); }}
                className="px-2.5 py-1 rounded-full text-xs border transition-all hover:border-amber-400"
                style={{ background: '#f5f2ed', borderColor: '#d4c9b8', color: '#6b5a4a' }}
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mt-8">
          {[
            { icon: FileText, label: 'Cases Indexed', value: '45M+' },
            { icon: Users, label: 'Legal Professionals', value: '12K+' },
            { icon: TrendingUp, label: 'Queries Answered', value: '2M+' },
          ].map(({ icon: Icon, label, value }) => (
            <div key={label} className="rounded-lg p-4 text-center border" style={{ background: 'white', borderColor: '#e5e0d8' }}>
              <div className="flex justify-center mb-2">
                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#f5f2ed' }}>
                  <Icon size={14} style={{ color: '#8b6f4e' }} />
                </div>
              </div>
              <p className="text-lg font-semibold" style={{ color: '#1a1a2e', fontFamily: 'Crimson Pro, serif' }}>{value}</p>
              <p className="text-xs" style={{ color: '#6b5a4a' }}>{label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Features */}
      <div className="max-w-3xl mx-auto px-6 py-8">
        <h2 className="text-center text-sm font-medium mb-6" style={{ color: '#6b5a4a' }}>
          BUILT FOR LEGAL PROFESSIONALS
        </h2>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {[
            {
              icon: Zap,
              title: 'AI Legal Research',
              desc: 'Ask any legal question and get a comprehensive answer with cited sources, holdings, and analysis.',
              cta: 'Try Research',
              action: () => onResearch('What is the pleading standard for federal civil complaints?'),
            },
            {
              icon: Scale,
              title: 'Case Law Database',
              desc: 'Search 45M+ cases with natural language. Filter by jurisdiction, court, date, and practice area.',
              cta: 'Search Cases',
              action: () => onSearch('pleading standard'),
            },
            {
              icon: Shield,
              title: 'Citation Verification',
              desc: 'Automatically verify citations, check case status, and detect overruled or distinguished precedents.',
              cta: 'Verify Citation',
              action: () => onSearch('Chevron deference'),
            },
          ].map(({ icon: Icon, title, desc, cta, action }) => (
            <div
              key={title}
              className="rounded-xl p-5 border hover:shadow-md transition-all cursor-pointer group"
              style={{ background: 'white', borderColor: '#e5e0d8' }}
              onClick={action}
            >
              <div className="w-9 h-9 rounded-lg flex items-center justify-center mb-3" style={{ background: '#f5f2ed' }}>
                <Icon size={16} style={{ color: '#8b6f4e' }} />
              </div>
              <h3 className="font-semibold text-sm mb-1.5" style={{ color: '#1a1a2e' }}>{title}</h3>
              <p className="text-xs mb-3" style={{ color: '#6b5a4a', lineHeight: 1.6 }}>{desc}</p>
              <button className="flex items-center gap-1 text-xs font-medium group-hover:gap-2 transition-all" style={{ color: '#8b6f4e' }}>
                {cta} <ArrowRight size={11} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Recent cases */}
      <div className="max-w-3xl mx-auto px-6 pb-16">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-medium" style={{ color: '#1a1a2e' }}>Landmark Cases</h2>
          <button className="text-xs flex items-center gap-1" style={{ color: '#8b6f4e' }} onClick={() => onSearch('')}>
            View all <ArrowRight size={11} />
          </button>
        </div>
        <div className="space-y-2">
          {[
            { name: 'Bell Atl. Corp. v. Twombly', citation: '550 U.S. 544 (2007)', area: 'Civil Procedure', status: 'good', q: 'twombly pleading' },
            { name: 'Loper Bright Enterprises v. Raimondo', citation: '603 U.S. ___ (2024)', area: 'Administrative Law', status: 'good', q: 'Chevron deference overruled' },
            { name: 'Miranda v. Arizona', citation: '384 U.S. 436 (1966)', area: 'Criminal Law', status: 'good', q: 'Miranda rights' },
            { name: 'Chevron U.S.A., Inc. v. NRDC', citation: '467 U.S. 837 (1984)', area: 'Administrative Law', status: 'bad', q: 'Chevron deference' },
          ].map(({ name, citation, area, status, q }) => (
            <div
              key={name}
              onClick={() => onSearch(q)}
              className="flex items-center gap-3 p-3 rounded-lg border cursor-pointer hover:shadow-sm transition-all"
              style={{ background: 'white', borderColor: '#e5e0d8' }}
            >
              <div className={`w-2 h-2 rounded-full flex-shrink-0 ${status === 'good' ? 'bg-green-500' : status === 'bad' ? 'bg-red-500' : 'bg-yellow-500'}`} />
              <div className="flex-1 min-w-0">
                <span className="text-xs font-medium" style={{ color: '#1a1a2e' }}>{name}</span>
                <span className="text-xs ml-2" style={{ color: '#8b6f4e' }}>{citation}</span>
              </div>
              <span className="text-xs px-2 py-0.5 rounded-full flex-shrink-0" style={{ background: '#f5f2ed', color: '#6b5a4a' }}>{area}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
