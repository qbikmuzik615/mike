import { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, BookOpen, ChevronRight, RotateCcw, Copy, ThumbsUp, ThumbsDown, ExternalLink, Search, Scale } from 'lucide-react';
import { CASES, RESEARCH_ANSWERS, SAMPLE_QUERIES } from '../data/cases';
import { ResearchSession } from '../types';

interface ResearchPageProps {
  initialQuery: string;
  onSelectCase: (id: string) => void;
}

function ThinkingDots() {
  return (
    <div className="flex items-center gap-1 px-4 py-3">
      <div className="w-2 h-2 rounded-full dot-1" style={{ background: '#8b6f4e' }} />
      <div className="w-2 h-2 rounded-full dot-2" style={{ background: '#8b6f4e' }} />
      <div className="w-2 h-2 rounded-full dot-3" style={{ background: '#8b6f4e' }} />
    </div>
  );
}

function SourceCard({ caseId, onSelect }: { caseId: string; onSelect: () => void }) {
  const c = CASES.find(x => x.id === caseId);
  if (!c) return null;
  return (
    <div
      className="source-card flex-shrink-0 w-52 border rounded-lg p-3 cursor-pointer"
      style={{ background: 'white', borderColor: '#e5e0d8' }}
      onClick={onSelect}
    >
      <div className="flex items-start justify-between gap-1 mb-1.5">
        <p className="text-xs font-semibold leading-tight" style={{ color: '#1a1a2e' }}>{c.shortName}</p>
        <ExternalLink size={10} className="flex-shrink-0 mt-0.5" style={{ color: '#8b8b8b' }} />
      </div>
      <p className="text-xs mb-2" style={{ color: '#8b6f4e' }}>{c.citation}</p>
      <div className={`inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium border ${
        c.status === 'good' ? 'badge-good' : c.status === 'bad' ? 'badge-bad' : 'badge-caution'
      }`}>
        {c.status === 'good' ? '✓' : c.status === 'bad' ? '✗' : '⚠'} {c.statusLabel}
      </div>
    </div>
  );
}

function AnswerCard({ session, onSelectCase }: { session: ResearchSession; onSelectCase: (id: string) => void }) {
  const [copied, setCopied] = useState(false);
  const [thumbs, setThumbs] = useState<'up' | 'down' | null>(null);

  const handleCopy = () => {
    navigator.clipboard.writeText(session.answer);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Simple markdown-like rendering
  const renderAnswer = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, i) => {
      if (line.startsWith('**') && line.endsWith('**')) {
        return <h3 key={i} className="font-semibold text-sm mt-3 mb-1" style={{ color: '#1a1a2e' }}>{line.replace(/\*\*/g, '')}</h3>;
      }
      if (line.match(/^\d+\.\s/)) {
        return (
          <div key={i} className="flex gap-2 text-sm mb-1" style={{ color: '#3a3a3a' }}>
            <span className="flex-shrink-0 font-medium" style={{ color: '#8b6f4e' }}>{line.match(/^\d+/)?.[0]}.</span>
            <span dangerouslySetInnerHTML={{ __html: line.replace(/^\d+\.\s/, '').replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/\*(.+?)\*/g, '<em>$1</em>') }} />
          </div>
        );
      }
      if (line.trim() === '') return <div key={i} className="h-2" />;
      return (
        <p key={i} className="text-sm mb-2 leading-relaxed"
          style={{ color: '#3a3a3a', fontFamily: 'Crimson Pro, Georgia, serif', fontSize: '1rem' }}
          dangerouslySetInnerHTML={{ __html: line.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/\*(.+?)\*/g, '<em>$1</em>') }}
        />
      );
    });
  };

  return (
    <div className="mb-8">
      {/* User query */}
      <div className="flex justify-end mb-4">
        <div className="max-w-xl px-4 py-3 rounded-2xl text-sm" style={{ background: '#1a1a2e', color: 'white' }}>
          {session.query}
        </div>
      </div>

      {/* AI Answer */}
      <div className="flex gap-3">
        <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5" style={{ background: '#f5f2ed', border: '1px solid #d4c9b8' }}>
          <Scale size={14} style={{ color: '#8b6f4e' }} />
        </div>
        <div className="flex-1 min-w-0">
          {/* Answer text */}
          <div className="rounded-2xl p-5 border mb-4" style={{ background: 'white', borderColor: '#e5e0d8' }}>
            <div className="leading-relaxed">
              {renderAnswer(session.answer)}
            </div>
          </div>

          {/* Sources */}
          {session.sources.length > 0 && (
            <div className="mb-4">
              <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: '#6b5a4a' }}>
                <BookOpen size={11} className="inline mr-1" />
                Sources
              </p>
              <div className="flex gap-3 overflow-x-auto pb-2" style={{ scrollbarWidth: 'none' }}>
                {session.sources.map(src => (
                  <SourceCard
                    key={src.caseId}
                    caseId={src.caseId}
                    onSelect={() => onSelectCase(src.caseId)}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center gap-2">
            <button onClick={handleCopy} className="flex items-center gap-1 px-2.5 py-1 rounded text-xs border hover:bg-gray-50 transition-all" style={{ borderColor: '#d4c9b8', color: '#5a5a5a' }}>
              <Copy size={11} /> {copied ? 'Copied!' : 'Copy'}
            </button>
            <button
              onClick={() => setThumbs('up')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs border hover:bg-gray-50 transition-all ${thumbs === 'up' ? 'text-green-700' : ''}`}
              style={{ borderColor: '#d4c9b8', color: thumbs === 'up' ? '#166534' : '#5a5a5a' }}
            >
              <ThumbsUp size={11} />
            </button>
            <button
              onClick={() => setThumbs('down')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs border hover:bg-gray-50 transition-all ${thumbs === 'down' ? 'text-red-700' : ''}`}
              style={{ borderColor: '#d4c9b8', color: thumbs === 'down' ? '#991b1b' : '#5a5a5a' }}
            >
              <ThumbsDown size={11} />
            </button>
          </div>

          {/* Follow-up suggestions */}
          {session.followUps.length > 0 && (
            <div className="mt-4">
              <p className="text-xs mb-2" style={{ color: '#6b5a4a' }}>Follow-up questions:</p>
              <div className="space-y-1.5">
                {session.followUps.map(q => (
                  <button
                    key={q}
                    className="flex items-center gap-2 w-full text-left px-3 py-2 rounded-lg border text-xs hover:shadow-sm transition-all"
                    style={{ background: 'white', borderColor: '#e5e0d8', color: '#4a4a4a' }}
                  >
                    <ChevronRight size={12} style={{ color: '#8b6f4e', flexShrink: 0 }} />
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function ResearchPage({ initialQuery, onSelectCase }: ResearchPageProps) {
  const [sessions, setSessions] = useState<ResearchSession[]>([]);
  const [inputVal, setInputVal] = useState('');
  const [thinking, setThinking] = useState(false);
  const [history, setHistory] = useState<string[]>([]);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const generateAnswer = (query: string): ResearchSession => {
    const isMiranda = query.toLowerCase().includes('miranda') || query.toLowerCase().includes('custodial') || query.toLowerCase().includes('interrogation') || query.toLowerCase().includes('rights');
    const isPleading = query.toLowerCase().includes('pleading') || query.toLowerCase().includes('twombly') || query.toLowerCase().includes('iqbal') || query.toLowerCase().includes('12(b)(6)') || query.toLowerCase().includes('complaint');
    const isChevron = query.toLowerCase().includes('chevron') || query.toLowerCase().includes('deference') || query.toLowerCase().includes('agency') || query.toLowerCase().includes('administrative');
    const isErie = query.toLowerCase().includes('erie') || query.toLowerCase().includes('diversity') || query.toLowerCase().includes('state law');

    let selectedAnswer = RESEARCH_ANSWERS[0];
    if (isMiranda) selectedAnswer = RESEARCH_ANSWERS[1];

    const sources = selectedAnswer.sources.map(id => {
      const c = CASES.find(x => x.id === id)!;
      return { caseId: id, citation: c.citation, shortName: c.shortName, excerpt: c.excerpt, relevance: 'primary' as const };
    });

    if (isChevron || isErie || (!isPleading && !isMiranda)) {
      const relevantCases = isChevron
        ? ['chevron', 'loper']
        : isErie
        ? ['erie']
        : ['twombly', 'iqbal'];

      const chevronAnswer = `Under the landmark decision in **Loper Bright Enterprises v. Raimondo**, 603 U.S. ___ (2024), the Supreme Court **overruled Chevron U.S.A., Inc. v. Natural Resources Defense Council** and eliminated the longstanding doctrine of "Chevron deference."

**The Old Chevron Framework** (no longer applies):
Courts previously applied a two-step analysis when reviewing agency interpretations of ambiguous statutes:
1. **Step One**: Whether Congress has directly spoken to the precise question at issue
2. **Step Two**: Whether the agency's interpretation was a permissible (reasonable) construction of the statute

**Current Law Post-Loper Bright (2024)**:
Courts must now exercise **independent judgment** in determining the meaning of statutes, including those administered by agencies. The APA expressly requires courts to "decide all relevant questions of law" arising in administrative proceedings.

**Practical Impact**:
This is one of the most significant administrative law decisions in 40 years. Regulated parties may now have stronger grounds to challenge agency interpretations that previously enjoyed deference.`;

      const erieAnswer = `The **Erie doctrine**, established in *Erie Railroad Co. v. Tompkins*, 304 U.S. 64 (1938), requires federal courts exercising diversity jurisdiction to apply **state substantive law** rather than creating an independent federal common law.

**The Core Rule**:
> "Except in matters governed by the Federal Constitution or by Acts of Congress, the law to be applied in any case is the law of the State."

**Key Principles**:
1. **No federal general common law** — Congress has no power to declare substantive common law rules applicable in states
2. **Substantive vs. Procedural** — Federal courts apply state *substantive* law but federal *procedural* rules (FRCP)
3. **State common law included** — "Law of the State" includes both statutory and common law

**The *Klaxon* Extension**: Under *Klaxon Co. v. Stentor Electric Mfg. Co.*, 313 U.S. 487 (1941), federal courts must also apply the forum state's **conflict of laws** rules.`;

      return {
        id: Date.now().toString(),
        query,
        timestamp: new Date(),
        answer: isChevron ? chevronAnswer : isErie ? erieAnswer : selectedAnswer.answer,
        sources: relevantCases.map(id => {
          const c = CASES.find(x => x.id === id)!;
          return { caseId: id, citation: c?.citation || '', shortName: c?.shortName || '', excerpt: c?.excerpt || '', relevance: 'primary' as const };
        }).filter(s => s.citation),
        followUps: isChevron
          ? ['How does Loper Bright affect pending agency rulemaking?', 'Which agencies are most impacted by the end of Chevron deference?', 'What standard replaced Chevron after Loper Bright?']
          : isErie
          ? ['What is the outcome-determinative test for Erie?', 'How does Erie apply to statute of limitations questions?', 'What is the difference between substance and procedure under Erie?']
          : selectedAnswer.followUps,
      };
    }

    return {
      id: Date.now().toString(),
      query,
      timestamp: new Date(),
      answer: selectedAnswer.answer,
      sources,
      followUps: selectedAnswer.followUps,
    };
  };

  const submit = (q: string = inputVal) => {
    if (!q.trim() || thinking) return;
    const query = q.trim();
    setInputVal('');
    setHistory(prev => [query, ...prev.slice(0, 9)]);
    setThinking(true);

    setTimeout(() => {
      const session = generateAnswer(query);
      setSessions(prev => [...prev, session]);
      setThinking(false);
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    }, 1500 + Math.random() * 800);
  };

  useEffect(() => {
    if (initialQuery) {
      submit(initialQuery);
    }
  }, []);

  const isEmpty = sessions.length === 0 && !thinking;

  return (
    <div className="flex h-full" style={{ background: '#f8f7f4' }}>
      {/* Sidebar: history */}
      <aside className="w-56 flex-shrink-0 border-r bg-white overflow-auto sidebar-scroll" style={{ borderColor: '#e5e0d8' }}>
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-semibold uppercase tracking-wider" style={{ color: '#6b5a4a' }}>Research History</h3>
            {sessions.length > 0 && (
              <button onClick={() => { setSessions([]); setHistory([]); }} className="p-1 rounded hover:bg-gray-100 transition-all">
                <RotateCcw size={11} style={{ color: '#8b8b8b' }} />
              </button>
            )}
          </div>

          {history.length === 0 ? (
            <p className="text-xs" style={{ color: '#8b8b8b' }}>Your research history will appear here</p>
          ) : (
            <div className="space-y-1">
              {history.map((q, i) => (
                <button
                  key={i}
                  onClick={() => submit(q)}
                  className="w-full text-left px-2 py-2 rounded text-xs hover:bg-gray-50 transition-all leading-snug"
                  style={{ color: '#5a5a5a' }}
                >
                  {q.length > 60 ? q.slice(0, 60) + '…' : q}
                </button>
              ))}
            </div>
          )}

          <div className="mt-6">
            <p className="text-xs font-semibold uppercase tracking-wider mb-3" style={{ color: '#6b5a4a' }}>Suggested Topics</p>
            <div className="space-y-1">
              {SAMPLE_QUERIES.map(q => (
                <button
                  key={q}
                  onClick={() => submit(q)}
                  className="w-full text-left px-2 py-1.5 rounded text-xs hover:bg-gray-50 transition-all"
                  style={{ color: '#6b5a4a' }}
                >
                  <Search size={9} className="inline mr-1 opacity-60" />
                  {q}
                </button>
              ))}
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Messages area */}
        <div className="flex-1 overflow-auto px-6 py-6">
          {isEmpty ? (
            <div className="max-w-2xl mx-auto">
              <div className="text-center mb-8 pt-8">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: '#f5f2ed', border: '1px solid #d4c9b8' }}>
                  <Sparkles size={20} style={{ color: '#8b6f4e' }} />
                </div>
                <h2 className="font-serif text-2xl mb-2" style={{ color: '#1a1a2e', fontFamily: 'Crimson Pro, serif' }}>
                  AI Legal Research
                </h2>
                <p className="text-sm" style={{ color: '#6b5a4a' }}>
                  Ask any legal question. Get comprehensive answers with cited sources.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {[
                  'What is the federal pleading standard after Twombly and Iqbal?',
                  'What Miranda rights must police advise suspects of?',
                  'How did Loper Bright change Chevron deference?',
                  'What law applies in federal diversity cases under Erie?',
                ].map(q => (
                  <button
                    key={q}
                    onClick={() => submit(q)}
                    className="text-left p-4 rounded-xl border hover:shadow-md transition-all text-sm"
                    style={{ background: 'white', borderColor: '#e5e0d8', color: '#3a3a3a' }}
                  >
                    <ChevronRight size={12} className="mb-2" style={{ color: '#8b6f4e' }} />
                    {q}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="max-w-3xl mx-auto">
              {sessions.map(s => (
                <AnswerCard key={s.id} session={s} onSelectCase={onSelectCase} />
              ))}
              {thinking && (
                <div className="flex gap-3 mb-6">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: '#f5f2ed', border: '1px solid #d4c9b8' }}>
                    <Scale size={14} style={{ color: '#8b6f4e' }} />
                  </div>
                  <div className="rounded-2xl border" style={{ background: 'white', borderColor: '#e5e0d8' }}>
                    <div className="px-2 py-1">
                      <p className="text-xs px-2 pt-2 pb-0" style={{ color: '#8b8b8b' }}>Researching case law…</p>
                      <ThinkingDots />
                    </div>
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>
          )}
        </div>

        {/* Input area */}
        <div className="flex-shrink-0 border-t p-4" style={{ background: 'white', borderColor: '#e5e0d8' }}>
          <div className="max-w-3xl mx-auto">
            <div className="flex gap-3 items-end">
              <div className="flex-1 rounded-xl border overflow-hidden transition-all" style={{ borderColor: '#d4c9b8' }}>
                <input
                  ref={inputRef}
                  type="text"
                  value={inputVal}
                  onChange={e => setInputVal(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && submit()}
                  placeholder="Ask a legal research question..."
                  className="w-full px-4 py-3 text-sm bg-transparent search-input"
                  style={{ outline: 'none', color: '#1a1a2e' }}
                  disabled={thinking}
                />
              </div>
              <button
                onClick={() => submit()}
                disabled={!inputVal.trim() || thinking}
                className="w-10 h-10 rounded-xl flex items-center justify-center text-white transition-all hover:opacity-90 disabled:opacity-40 flex-shrink-0"
                style={{ background: '#1a1a2e' }}
              >
                <Send size={14} />
              </button>
            </div>
            <p className="text-xs text-center mt-2" style={{ color: '#a0a0a0' }}>
              AI research is for informational purposes only. Always verify with primary sources.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
