export type View = 'home' | 'search' | 'case' | 'research';

export interface Case {
  id: string;
  citation: string;
  shortName: string;
  fullName: string;
  court: string;
  date: string;
  year: number;
  jurisdiction: string;
  judges: string[];
  docketNumber: string;
  status: 'good' | 'bad' | 'caution' | 'neutral';
  statusLabel: string;
  headnotes: string[];
  holdings: string[];
  excerpt: string;
  fullText: Section[];
  citedBy: CitingCase[];
  cites: string[];
  practiceAreas: string[];
  relevanceScore?: number;
  snippet?: string;
}

export interface Section {
  id: string;
  heading?: string;
  content: string;
  highlights?: Highlight[];
}

export interface Highlight {
  start: number;
  end: number;
  text: string;
  note?: string;
}

export interface CitingCase {
  id: string;
  citation: string;
  shortName: string;
  court: string;
  year: number;
  treatment: 'follows' | 'distinguishes' | 'criticizes' | 'overrules' | 'explains';
  snippet: string;
}

export interface SearchResult {
  caseId: string;
  relevance: number;
  snippet: string;
  matchedTerms: string[];
}

export interface ResearchSession {
  id: string;
  query: string;
  timestamp: Date;
  answer: string;
  sources: SourceReference[];
  followUps: string[];
}

export interface SourceReference {
  caseId: string;
  citation: string;
  shortName: string;
  excerpt: string;
  page?: string;
  relevance: 'primary' | 'secondary' | 'background';
}

export interface SavedItem {
  id: string;
  type: 'case' | 'query';
  caseId?: string;
  query?: string;
  savedAt: Date;
  notes?: string;
  folder?: string;
}

export interface Folder {
  id: string;
  name: string;
  color: string;
  count: number;
}
