import { useState } from 'react';
import TopNav from './components/TopNav';
import HomePage from './components/HomePage';
import SearchPage from './components/SearchPage';
import CaseViewer from './components/CaseViewer';
import ResearchPage from './components/ResearchPage';

type View = 'home' | 'search' | 'case' | 'research';

export default function App() {
  const [view, setView] = useState<View>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCase, setSelectedCase] = useState<string | null>(null);
  const [researchQuery, setResearchQuery] = useState('');

  const handleSearch = (q: string) => {
    setSearchQuery(q);
    setView('search');
  };

  const handleResearch = (q: string) => {
    setResearchQuery(q);
    setView('research');
  };

  const handleSelectCase = (id: string) => {
    setSelectedCase(id);
    setView('case');
  };

  const handleNavigate = (v: string) => {
    if (v === 'home') setView('home');
    else if (v === 'search') setView('search');
    else if (v === 'research') { setResearchQuery(''); setView('research'); }
    else setView(v as View);
  };

  return (
    <div className="h-screen flex flex-col app-layout" style={{ background: '#f8f7f4' }}>
      <TopNav
        view={view}
        onNavigate={handleNavigate}
        onSearch={handleSearch}
        searchQuery={searchQuery}
      />

      <div className="flex-1 overflow-hidden">
        {view === 'home' && (
          <HomePage onSearch={handleSearch} onResearch={handleResearch} />
        )}
        {view === 'search' && (
          <SearchPage query={searchQuery} onSelectCase={handleSelectCase} />
        )}
        {view === 'case' && selectedCase && (
          <CaseViewer
            caseId={selectedCase}
            onBack={() => setView('search')}
            onSelectCase={handleSelectCase}
          />
        )}
        {view === 'research' && (
          <ResearchPage
            key={researchQuery}
            initialQuery={researchQuery}
            onSelectCase={handleSelectCase}
          />
        )}
      </div>
    </div>
  );
}
