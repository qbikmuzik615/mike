# CLAUDE.md — Legal Super-Brain v11.0 + Midpage Integration

## Project Overview
This is a full-stack React + TypeScript legal research platform combining:
- **Midpage UI** — case law search, case viewer, jurisdiction filtering
- **Legal Super-Brain v11.0** — 5 AI modes (Chat, Search, Draft, Analyze, Orchestrate) powered by Anthropic API streaming
- **Agent Orchestration** — 6-agent development team (PM, UX, FE, BE, DB, DevOps)

## Tech Stack
- React 18 + TypeScript + Vite
- TailwindCSS v3
- Lucide React icons
- Anthropic claude-sonnet-4-20250514 via streaming SSE

## Environment Variables
```
VITE_ANTHROPIC_API_KEY=your_key_here
```
Create a `.env.local` file at project root. **Never commit this file.**

## File Structure
```
src/
  components/
    TopNav.tsx          — header, mode tabs, jurisdiction display
    Sidebar.tsx         — left panel: threads, saved cases, context, settings
    HomePage.tsx        — landing hero, query input, sample queries
    ChatPage.tsx        — AI research chat with streaming
    DraftPage.tsx       — Scalia/Garner CRAC drafting mode
    AnalyzePage.tsx     — 37-trigger forensic transcript analysis
    OrchestratePage.tsx — POML prompt scoring + agent team panel
    SearchPage.tsx      — keyword/boolean case search with filters
    CaseViewer.tsx      — full case opinion, headnotes, citing cases
    JurisdictionModal.tsx — 50-state + federal circuit picker
    AgentTeamPanel.tsx  — 6-agent team display with triggers
    PhasesSection.tsx   — SDLC pipeline visualization (from framework)
    ModulesSection.tsx  — 7 framework modules display
    QASection.tsx       — compliance audit dashboard
    CollabSection.tsx   — requirement extraction Q&A
    Footer.tsx          — agent roster, quality mandates
  data/
    cases.ts            — Federal + TN/AL case law database
    systemPrompts.ts    — Full Legal Super-Brain v11.0 system prompts
    frameworkData.ts    — Agent team, phases, modules, QA checks
    jurisdictions.ts    — 50 states, federal circuits, other federal
  hooks/
    useAnthropicStream.ts — streaming API hook with abort support
    useThreads.ts         — conversation thread management
    useSavedCases.ts      — case bookmarking with localStorage
  utils/
    cn.ts               — className merge utility
    search.ts           — case search/ranking algorithm
    citations.ts        — Bluebook citation formatting helpers
  types.ts              — all TypeScript interfaces
  App.tsx               — root router
  main.tsx              — entry point
  index.css             — global styles, CSS variables
```

## Key Architecture Decisions
1. **System prompts** live in `src/data/systemPrompts.ts` — each mode has its own full prompt
2. **Streaming** uses Anthropic SSE via `useAnthropicStream` hook — abort controller included
3. **Jurisdiction** state flows: JurisdictionModal → App state → TopNav display → systemPrompts
4. **Pro Se mode** toggle injects Certificate of Service template into Draft mode system prompt
5. **Thread history** stored in component state (not localStorage) for privacy

## Claude Code Workflows

### Add a new AI mode
```bash
# 1. Add system prompt to src/data/systemPrompts.ts
# 2. Create src/components/[ModeName]Page.tsx
# 3. Add route in src/App.tsx
# 4. Add tab in src/components/TopNav.tsx MODE_TABS array
```

### Add new cases to the database
```bash
# Edit src/data/cases.ts
# Follow the Case interface in src/types.ts
# Add to CASES array (federal) or TN_CASES / AL_CASES arrays
```

### Update jurisdiction defaults
```bash
# Edit src/data/jurisdictions.ts
# Update JURISDICTION_DEFAULTS object for TN/AL presets
```

## Quality Gates (enforced in CI)
- TypeScript strict mode — no `any` without explicit justification
- ESLint — zero warnings in CI
- All API calls must use the `useAnthropicStream` hook (not raw fetch)
- System prompts must follow POML template structure in systemPrompts.ts

## GitHub Actions
See `.github/workflows/` for:
- `ci.yml` — lint + type-check on every PR
- `deploy.yml` — Vercel preview on PR, production on main merge

## Common Commands
```bash
npm run dev          # start dev server at localhost:5173
npm run build        # production build
npm run type-check   # TypeScript check without emit
npm run lint         # ESLint check
```

---

## 🤖 First Session — Claude Code Prompts (run in order)

Copy-paste these into `claude` when you first open the project.

### Session 1 — Get it running
```
Run `npm run dev`. Fix any TypeScript or import errors you find. 
Don't change functionality — just make it compile clean.
```

### Session 2 — Wire up HomePage
```
src/components/HomePage.tsx doesn't exist yet. Create it.
It should show:
- A hero with serif headline "Legal research that thinks with you"
- A search input that calls onSearch(q) prop
- 4 mode cards (Chat / Draft / Analyze / Orchestrate) that call onModeSelect(mode)
- Use the parchment color scheme from index.css
```

### Session 3 — Extend case database
```
Open src/data/cases.ts. The CASES array has federal cases.
Add 5 more Tennessee cases relevant to family law and orders of protection.
Follow the exact Case interface from src/types.ts.
Include: Barnhill v. Barnhill, Eldridge v. Eldridge, and State v. Turner.
```

### Session 4 — Add keyboard shortcuts
```
In App.tsx, add keyboard shortcuts:
- Cmd+1 → chat mode
- Cmd+2 → draft mode  
- Cmd+3 → analyze mode
- Cmd+4 → orchestrate mode
- Cmd+K → focus search
- Escape → close modals
Use a useEffect with keydown listener. Clean it up on unmount.
```

### Session 5 — Thread persistence
```
Right now threads[] in App.tsx is just React state and resets on refresh.
Add localStorage persistence for threads using a custom useThreads hook 
in src/hooks/useThreads.ts. 
Serialize/deserialize messages array. Cap at 50 threads.
```

### Session 6 — Production build + deploy
```
Run `npm run build`. Fix any build errors.
Then run `npm run preview` to verify the production build works.
Output the list of bundle sizes by file.
```
