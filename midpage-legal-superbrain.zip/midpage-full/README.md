# midpage — Legal Super-Brain v11.0

> AI-powered legal research platform. Midpage UI + Legal Super-Brain v11.0 methodology + Anthropic claude-sonnet-4 streaming.

## Features

| Mode | Description |
|------|-------------|
| **Chat** | Legal research Q&A with Bluebook citations, shepherd signals, IRAC structure |
| **Drafting** | Scalia/Garner CRAC method, 6-pass multi-persona revision, pro se formatting |
| **Analyze** | 6-stage forensic pipeline, 37-trigger taxonomy, 11-section report |
| **Orchestrate** | POML prompt scoring (Before/After), 6-agent Digital Software Agency |
| **Case Search** | Keyword/boolean search, case viewer, jurisdiction filtering |

## Quick Start

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/midpage-legal-superbrain
cd midpage-legal-superbrain

# 2. Install
npm install

# 3. Environment — copy and fill in your Anthropic API key
cp .env.example .env.local
# Edit .env.local: VITE_ANTHROPIC_API_KEY=sk-ant-...

# 4. Run
npm run dev
# → http://localhost:5173
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `VITE_ANTHROPIC_API_KEY` | Anthropic API key — **never commit this** |

## Claude Code Usage

This project has a `CLAUDE.md` file with full instructions for Claude Code:

```bash
# Install Claude Code
npm install -g @anthropic-ai/claude-code

# Run in project directory
claude
```

Common Claude Code tasks:
- "Add a new jurisdiction preset for Alabama probate"
- "Add a Motion to Strike template to draft mode examples"
- "Create a new AI mode called 'Strategy' using the ANALYZE_PROMPT as base"

## Project Structure

```
src/
  components/
    TopNav.tsx          ← header + mode tabs + jurisdiction
    Sidebar.tsx         ← threads, saved cases, context, pro se
    HomePage.tsx        ← landing + framework sections
    ChatPage.tsx        ← all 4 AI modes (chat/draft/analyze/orchestrate)
    SearchPage.tsx      ← case keyword search
    CaseViewer.tsx      ← full case opinion + citing cases
    JurisdictionModal.tsx ← 50-state + circuit picker
    AgentTeamPanel.tsx  ← 6-agent team with triggers
    PhasesSection.tsx   ← SDLC pipeline display
    ModulesSection.tsx  ← 7 framework modules
    QASection.tsx       ← compliance audit
    CollabSection.tsx   ← requirement Q&A
    Footer.tsx
  data/
    cases.ts            ← Federal + TN/AL case database
    systemPrompts.ts    ← Legal Super-Brain v11.0 prompts
    frameworkData.ts    ← agents, phases, modules, QA checks
    jurisdictions.ts    ← all 50 states + circuits
  hooks/
    useAnthropicStream.ts ← SSE streaming with abort
  utils/
    cn.ts, search.ts
  types.ts
  App.tsx
```

## Deployment

### Vercel (Recommended)
1. Push to GitHub
2. Import repo in [vercel.com](https://vercel.com)
3. Set `VITE_ANTHROPIC_API_KEY` in Vercel environment variables
4. Deploy

### GitHub Actions
CI runs on every PR: lint → type-check → build  
CD deploys to Vercel on push to `main`

Set these GitHub secrets:
- `VITE_ANTHROPIC_API_KEY`
- `VERCEL_TOKEN`
- `VERCEL_ORG_ID`
- `VERCEL_PROJECT_ID`

## Legal Super-Brain Methodology

- **Scalia/Garner CRAC**: Concentration principle, syllogistic framing, 6-pass revision
- **37-Trigger Taxonomy**: F1-F5 Factual, L1-L5 Legal, P1-P6 Procedural, E1-E6 Ethical, V1-V5 Evidentiary, C1-C5 Credibility, S1-S5 Strategic
- **Interpretive Hierarchy**: Plain text → Structural context → Textual canons → Purposivism (only if ambiguous)
- **Jurisdiction Defaults**: Tennessee (T.C.A. Title 36, 6th Cir.) and Alabama (Ala. Code Title 43, 11th Cir.) pre-loaded
- **POML Scoring**: 5-dimension quality matrix, Before/After comparison

## License

MIT
