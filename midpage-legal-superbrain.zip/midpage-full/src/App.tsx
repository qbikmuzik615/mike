import { useState } from 'react';
import Sidebar from './components/Sidebar';
import TopNav from './components/TopNav';
import HomePage from './components/HomePage';
import ChatPage from './components/ChatPage';
import SearchPage from './components/SearchPage';
import CaseViewer from './components/CaseViewer';
import JurisdictionModal from './components/JurisdictionModal';
import AgentTeamPanel from './components/AgentTeamPanel';
import { PhasesSection } from './components/PhasesSection';
import { ModulesSection } from './components/ModulesSection';
import { QASection } from './components/QASection';
import { CollabSection } from './components/CollabSection';
import { Footer } from './components/Footer';
import { JURISDICTION_PRESETS } from './data/jurisdictions';
import type { View, Thread, JurisdictionSelection, AIMode } from './types';

type FrameworkView = 'phases' | 'modules' | 'qa' | 'collab';

export default function App() {
  // ── Routing ──
  const [view, setView] = useState<View>('home');
  const [aiMode, setAiMode] = useState<AIMode>('chat');
  const [frameworkView, setFrameworkView] = useState<FrameworkView | null>(null);

  // ── Case ──
  const [selectedCase, setSelectedCase] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // ── Threads & Chat ──
  const [threads, setThreads] = useState<Thread[]>([]);
  const [activeThreadId, setActiveThreadId] = useState<number | undefined>();
  const [chatMessages, setChatMessages] = useState<import('./types').Message[]>([]);

  // ── Settings ──
  const [context, setContext] = useState('');
  const [proSe, setProSe] = useState(true);
  const [savedCases, setSavedCases] = useState<string[]>(['twombly', 'miranda']);
  const [jurisdictionSel, setJurisdictionSel] = useState<JurisdictionSelection>(
    JURISDICTION_PRESETS.TN_DEFAULT
  );
  const [showJurModal, setShowJurModal] = useState(false);
  const [showAgentPanel, setShowAgentPanel] = useState(false);

  // ── Computed jurisdiction display ──
  const jurisdictionDisplay = (() => {
    const states = jurisdictionSel.state.length > 0
      ? jurisdictionSel.state[0] + (jurisdictionSel.state.length > 1 ? ` +${jurisdictionSel.state.length - 1}` : '')
      : '';
    const fed = jurisdictionSel.federal.length > 0
      ? jurisdictionSel.federal[0]
      : '';
    return [states, fed].filter(Boolean).join(' · ') || 'All Jurisdictions';
  })();

  // ── Handlers ──
  const handleSearch = (q: string) => {
    setSearchQuery(q);
    setView('search');
    setSelectedCase(null);
  };

  const handleResearch = (q: string) => {
    setAiMode('chat');
    setView('chat');
  };

  const handleSelectCase = (id: string) => {
    setSelectedCase(id);
    setView('case');
  };

  const handleNewThread = () => {
    setChatMessages([]);
    setActiveThreadId(undefined);
    setView('home');
  };

  const handleLoadThread = (thread: Thread) => {
    setAiMode(thread.mode);
    setView(thread.mode);
    setActiveThreadId(thread.id);
  };

  const handleNavigate = (v: string) => {
    if (v === 'home') { setView('home'); setFrameworkView(null); }
    else if (v === 'search') { setView('search'); setSelectedCase(null); }
    else if (v === 'chat') { setView('chat'); setAiMode('chat'); }
    else if (v === 'draft') { setView('chat'); setAiMode('draft'); }
    else if (v === 'analyze') { setView('chat'); setAiMode('analyze'); }
    else if (v === 'orchestrate') { setView('chat'); setAiMode('orchestrate'); }
    else if (v === 'case') { setView('case'); }
  };

  const handleModeChange = (mode: AIMode) => {
    setAiMode(mode);
    setView('chat');
  };

  const handleJurisdictionApply = (sel: JurisdictionSelection) => {
    setJurisdictionSel(sel);
  };

  const isAIView = view === 'chat';

  return (
    <div className="flex h-screen overflow-hidden bg-[#f8f7f4]">
      {/* Jurisdiction Modal */}
      {showJurModal && (
        <JurisdictionModal
          selected={jurisdictionSel}
          onClose={() => setShowJurModal(false)}
          onApply={sel => { handleJurisdictionApply(sel); setShowJurModal(false); }}
        />
      )}

      {/* Sidebar */}
      <Sidebar
        view={view}
        threads={threads}
        savedCases={savedCases}
        context={context}
        proSe={proSe}
        onNewThread={handleNewThread}
        onLoadThread={handleLoadThread}
        onSetContext={setContext}
        onToggleProSe={() => setProSe(p => !p)}
        onNavigate={v => handleNavigate(v)}
        activeThreadId={activeThreadId}
      />

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* TopNav */}
        <TopNav
          view={view}
          aiMode={aiMode}
          jurisdiction={jurisdictionDisplay}
          proSe={proSe}
          searchQuery={searchQuery}
          onNavigate={handleNavigate}
          onSearch={handleSearch}
          onModeChange={handleModeChange}
          onOpenJurisdiction={() => setShowJurModal(true)}
          onToggleAgents={() => setShowAgentPanel(p => !p)}
          agentsOpen={showAgentPanel}
        />

        {/* Agent Team Panel (Orchestrate mode) */}
        {aiMode === 'orchestrate' && isAIView && showAgentPanel && (
          <div className="px-6 py-3 border-b border-[#e5e0d8] bg-[#f8f7f4]">
            <AgentTeamPanel />
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-hidden">
          {view === 'home' && (
            <div className="h-full overflow-y-auto" style={{ background: '#f8f7f4' }}>
              <HomePage onSearch={handleSearch} onResearch={handleResearch} onModeSelect={handleModeChange} />
              {/* Framework sections */}
              <div className="bg-[#0d0d1a] text-white">
                <PhasesSection />
                <ModulesSection />
                <CollabSection />
                <QASection />
                <Footer />
              </div>
            </div>
          )}

          {view === 'chat' && (
            <ChatPage
              mode={aiMode}
              jurisdiction={jurisdictionDisplay}
              proSe={proSe}
              context={context}
            />
          )}

          {view === 'search' && !selectedCase && (
            <SearchPage query={searchQuery} onSelectCase={handleSelectCase} />
          )}

          {(view === 'case' || (view === 'search' && selectedCase)) && selectedCase && (
            <CaseViewer
              caseId={selectedCase}
              onBack={() => { setSelectedCase(null); setView('search'); }}
              onSelectCase={handleSelectCase}
            />
          )}
        </div>
      </div>
    </div>
  );
}
