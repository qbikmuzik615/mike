import { useState, useRef, useCallback } from 'react';
import type { Message } from '../types';

interface UseAnthropicStreamOptions {
  systemPrompt: string;
  onComplete?: (text: string) => void;
}

export function useAnthropicStream({ systemPrompt, onComplete }: UseAnthropicStreamOptions) {
  const [streaming, setStreaming] = useState(false);
  const [streamText, setStreamText] = useState('');
  const abortRef = useRef<AbortController | null>(null);

  const stream = useCallback(async (messages: Message[]): Promise<string> => {
    if (streaming) return '';
    
    abortRef.current = new AbortController();
    setStreaming(true);
    setStreamText('');
    let full = '';

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: abortRef.current.signal,
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 4000,
          stream: true,
          system: systemPrompt,
          messages,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error?.message || `API error ${res.status}`);
      }

      const reader = res.body!.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const lines = decoder.decode(value).split('\n');
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const data = line.slice(6).trim();
          if (data === '[DONE]') continue;
          try {
            const parsed = JSON.parse(data);
            if (parsed.type === 'content_block_delta' && parsed.delta?.text) {
              full += parsed.delta.text;
              setStreamText(full);
            }
          } catch {
            // Skip malformed SSE lines
          }
        }
      }

      onComplete?.(full);
      return full;
    } catch (err: unknown) {
      if ((err as Error).name === 'AbortError') return '';
      throw err;
    } finally {
      setStreaming(false);
      setStreamText('');
    }
  }, [streaming, systemPrompt, onComplete]);

  const abort = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  return { stream, abort, streaming, streamText };
}
