import type { Case } from '../types';

export function searchCases(cases: Case[], query: string): Case[] {
  if (!query.trim()) return cases;
  const q = query.toLowerCase();
  const terms = q.split(/\s+/).filter(Boolean);

  return cases
    .map(c => {
      let score = 0;
      const text = [
        c.shortName,
        c.citation,
        c.excerpt,
        c.snippet || '',
        ...(c.holdings || []),
        ...(c.headnotes || []),
        ...(c.practiceAreas || []),
      ].join(' ').toLowerCase();

      for (const term of terms) {
        if (c.shortName.toLowerCase().includes(term)) score += 40;
        else if (c.citation.toLowerCase().includes(term)) score += 30;
        else if ((c.practiceAreas || []).some(p => p.toLowerCase().includes(term))) score += 20;
        else if (text.includes(term)) score += 10;
      }

      return { ...c, relevanceScore: Math.min(score, 99) };
    })
    .filter(c => (c.relevanceScore || 0) > 0)
    .sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));
}

export function highlightText(text: string, query: string): string {
  if (!query) return text;
  const terms = query.split(/\s+/).filter(Boolean);
  let result = text;
  for (const term of terms) {
    const re = new RegExp(`(${term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    result = result.replace(re, '<mark>$1</mark>');
  }
  return result;
}
