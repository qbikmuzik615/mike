import { useState, useEffect } from 'react';
import { Filter, ChevronDown, ChevronRight, Star, BookmarkPlus, AlertTriangle, CheckCircle, XCircle, Clock, Scale } from 'lucide-react';
import { CASES } from '../data/cases';
import { Case } from '../types';

interface SearchPageProps {
  query: string;
  onSelectCase: (id: string) => void;
}

const STATUS_CONFIG = {
  good: { icon: CheckCircle, label: 'Good Law', color: '#166534', bg: '#dcfce7', border: '#86efac' },
  bad: { icon: XCircle, label: 'Overruled', color: '#991b1b', bg: '#fee2e2', border: '#fca5a5' },
  caution: { icon: AlertTriangle, label: 'Caution', color: '#854d0e', bg: '#fef9c3', border: '#fde047' },
  neutral: { icon: Clock, label: 'Neutral', color: '#475569', bg: '#f1f5f9', border: '#cbd5e1' },
};

const FILTERS = {
  court: ['Supreme Court', 'Circuit Courts', 'District Courts', 'State Courts'],
  date: ['Last year', 'Last 5 years', 'Last 10 years', 'All time'],
  area: ['Civil Procedure', 'Criminal Law', 'Constitutional Law', 'Administrative Law', 'Contract Law', 'Tort Law'],
  status: ['Good Law', 'Caution', 'Overruled'],
};

function StatusBadge({ status }: { status: Case['status'] }) {
  const cfg = STATUS_CONFIG[status];
  const Icon = cfg.icon;
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium border"
      style={{ color: cfg.color, background: cfg.bg, borderColor: cfg.border }}>
      <Icon size={10} />
      {cfg.label}
    </span>
  );
}

function CaseCard({ c, onSelect }: { c: Case; onSelect: () => void }) {
  const [saved, setSaved] = useState(false);

  return (
    <div
      className="bg-white rounded-xl border p-5 hover:shadow-md transition-all cursor-pointer group"
      style={{ borderColor: '#e5e0d8' }}
      onClick={onSelect}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <StatusBadge status={c.status} />
            {c.practiceAreas.slice(0, 2).map(a => (
              <span key={a} className="px-2 py-0.5 rounded-full text-xs border"
                style={{ background: '#f5f2ed', borderColor: '#d4c9b8', color: '#6b5a4a' }}>
                {a}
              </span>
            ))}
          </div>
          <h3 className="font-semibold text-sm mb-0.5 group-hover:text-amber-800 transition-colors" style={{ color: '#1a1a2e' }}>
            {c.shortName}
          </h3>
          <p className="text-xs" style={{ color: '#8b6f4e' }}>
            {c.citation} · {c.court} · {c.date}
          </p>
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          {c.relevanceScore && (
            <div className="flex items-center gap-1 px-2 py-1 rounded text-xs"
              style={{ background: '#f0f9ff', color: '#0369a1' }}>
              <Scale size={10} />
              {c.relevanceScore}%
            </div>
          )}
          <button
            onClick={e => { e.stopPropagation(); setSaved(!saved); }}
            className={`p-1.5 rounded hover:bg-gray-100 transition-all ${saved ? 'text-amber-600' : 'text-gray-400'}`}
          >
            {saved ? <Star size={14} fill="currentColor" /> : <BookmarkPlus size={14} />}
          </button>
        </div>
      </div>

      {/* Holdings */}
      {c.holdings[0] && (
        <div className="mb-3 p-3 rounded-lg text-xs leading-relaxed" style={{ background: '#fafaf8', color: '#4a4a4a', borderLeft: '3px solid #c8b89a' }}>
          <span className="font-medium" style={{ color: '#6b5a4a' }}>Holding: </span>
          {c.holdings[0]}
        </div>
      )}

      {/* Snippet */}
      <p className="text-xs leading-relaxed mb-3" style={{ color: '#5a5a5a' }}>
        {c.snippet}
      </p>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 text-xs" style={{ color: '#8b8b8b' }}>
          <span>{c.citedBy.length} citing cases</span>
          <span>·</span>
          <span>{c.judges[0]?.replace('Justice ', 'J. ').replace('Chief Justice ', 'C.J. ')}</span>
        </div>
        <button
          onClick={e => { e.stopPropagation(); onSelect(); }}
          className="flex items-center gap-1 text-xs font-medium opacity-0 group-hover:opacity-100 transition-all"
          style={{ color: '#8b6f4e' }}
        >
          View case <ChevronRight size={12} />
        </button>
      </div>
    </div>
  );
}

export default function SearchPage({ query, onSelectCase }: SearchPageProps) {
  const [results, setResults] = useState<Case[]>([]);
  const [_filtersOpen, setFiltersOpen] = useState(false);
  const [activeFilters, setActiveFilters] = useState<Record<string, string[]>>({});
  const [sortBy, setSortBy] = useState<'relevance' | 'date' | 'citations'>('relevance');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      const q = query.toLowerCase();
      let filtered = CASES.filter(c =>
        !q ||
        c.shortName.toLowerCase().includes(q) ||
        c.citation.toLowerCase().includes(q) ||
        c.fullText.some(s => s.content.toLowerCase().includes(q)) ||
        c.practiceAreas.some(a => a.toLowerCase().includes(q)) ||
        c.holdings.some(h => h.toLowerCase().includes(q)) ||
        c.snippet?.toLowerCase().includes(q)
      );
      if (sortBy === 'date') filtered.sort((a, b) => b.year - a.year);
      else if (sortBy === 'citations') filtered.sort((a, b) => b.citedBy.length - a.citedBy.length);
      else filtered.sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));
      setResults(filtered);
      setLoading(false);
    }, 400);
    return () => clearTimeout(timer);
  }, [query, sortBy]);

  return (
    <div className="flex h-full" style={{ background: '#f8f7f4' }}>
      {/* Sidebar filters */}
      <aside className="w-56 flex-shrink-0 border-r overflow-auto sidebar-scroll p-4 bg-white" style={{ borderColor: '#e5e0d8' }}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-semibold uppercase tracking-wider" style={{ color: '#6b5a4a' }}>Filters</h3>
          <Filter size={12} style={{ color: '#8b6f4e' }} />
        </div>

        {Object.entries(FILTERS).map(([key, values]) => (
          <div key={key} className="mb-5">
            <button
              onClick={() => setFiltersOpen(f => !f)}
              className="w-full flex items-center justify-between mb-2"
            >
              <span className="text-xs font-medium capitalize" style={{ color: '#1a1a2e' }}>{key}</span>
              <ChevronDown size={12} style={{ color: '#8b8b8b' }} />
            </button>
            <div className="space-y-1">
              {values.map(v => {
                const active = activeFilters[key]?.includes(v);
                return (
                  <label key={v} className="flex items-center gap-2 cursor-pointer group">
                    <div
                      onClick={() => {
                        setActiveFilters(prev => {
                          const cur = prev[key] || [];
                          return { ...prev, [key]: active ? cur.filter(x => x !== v) : [...cur, v] };
                        });
                      }}
                      className={`w-3.5 h-3.5 rounded border flex items-center justify-center transition-all ${active ? 'border-amber-700' : 'border-gray-300'}`}
                      style={active ? { background: '#8b6f4e', borderColor: '#8b6f4e' } : {}}
                    >
                      {active && <svg width="8" height="6" viewBox="0 0 8 6" fill="white"><path d="M1 3l2 2 4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>}
                    </div>
                    <span className="text-xs group-hover:text-gray-900 transition-colors" style={{ color: '#5a5a5a' }}>{v}</span>
                  </label>
                );
              })}
            </div>
          </div>
        ))}
      </aside>

      {/* Results */}
      <main className="flex-1 overflow-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div>
            {query ? (
              <h2 className="text-sm font-semibold" style={{ color: '#1a1a2e' }}>
                {loading ? 'Searching...' : `${results.length} results for "${query}"`}
              </h2>
            ) : (
              <h2 className="text-sm font-semibold" style={{ color: '#1a1a2e' }}>All Cases</h2>
            )}
            <p className="text-xs mt-0.5" style={{ color: '#6b5a4a' }}>
              Searching federal and state case law
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs" style={{ color: '#6b5a4a' }}>Sort by:</span>
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="text-xs border rounded px-2 py-1.5 bg-white"
              style={{ borderColor: '#d4c9b8', color: '#1a1a2e', outline: 'none' }}
            >
              <option value="relevance">Relevance</option>
              <option value="date">Date (newest)</option>
              <option value="citations">Most cited</option>
            </select>
          </div>
        </div>

        {/* Loading shimmer */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-white rounded-xl border p-5" style={{ borderColor: '#e5e0d8' }}>
                <div className="shimmer h-4 w-32 rounded mb-3" />
                <div className="shimmer h-5 w-64 rounded mb-2" />
                <div className="shimmer h-3 w-48 rounded mb-4" />
                <div className="shimmer h-16 rounded mb-3" />
                <div className="shimmer h-3 w-full rounded" />
              </div>
            ))}
          </div>
        ) : results.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Scale size={32} className="mb-4" style={{ color: '#c8b89a' }} />
            <h3 className="text-sm font-medium mb-1" style={{ color: '#1a1a2e' }}>No cases found</h3>
            <p className="text-xs" style={{ color: '#6b5a4a' }}>Try different search terms or remove filters</p>
          </div>
        ) : (
          <div className="space-y-4">
            {results.map(c => (
              <CaseCard key={c.id} c={c} onSelect={() => onSelectCase(c.id)} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
