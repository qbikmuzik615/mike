import { useState } from 'react';
import { Scale, Search, BookOpen, FileText, Activity, Cpu, Users, ChevronDown, Bell, HelpCircle } from 'lucide-react';
import type { View, AIMode } from '../types';

interface TopNavProps {
  view: View;
  aiMode: AIMode;
  jurisdiction: string;
  proSe: boolean;
  searchQuery: string;
  onNavigate: (view: string) => void;
  onSearch: (q: string) => void;
  onModeChange: (mode: AIMode) => void;
  onOpenJurisdiction: () => void;
  onToggleAgents: () => void;
  agentsOpen: boolean;
}

const AI_MODES: { id: AIMode; label: string; shortcut: string }[] = [
  { id: 'chat', label: 'Chat', shortcut: '1' },
  { id: 'draft', label: 'Drafting', shortcut: '2' },
  { id: 'analyze', label: 'Analyze', shortcut: '3' },
  { id: 'orchestrate', label: 'Orchestrate', shortcut: '4' },
];

export default function TopNav({ view, aiMode, jurisdiction, proSe, searchQuery, onNavigate, onSearch, onModeChange, onOpenJurisdiction, onToggleAgents, agentsOpen }: TopNavProps) {
  const [searchVal, setSearchVal] = useState(searchQuery);
  const [userOpen, setUserOpen] = useState(false);
  const isAI = view === 'chat';
  const isSearch = view === 'search' || view === 'case';

  return (
    <header className="h-11 flex-shrink-0 bg-white border-b border-[#e5e0d8] flex items-center px-4 gap-3 z-40">
      <button onClick={() => onNavigate('home')} className="flex items-center gap-2 flex-shrink-0">
        <div className="w-6 h-6 rounded flex items-center justify-center bg-[#1a1a2e]">
          <Scale size={12} className="text-white" />
        </div>
      </button>
      <div className="w-px h-5 bg-[#e5e0d8] flex-shrink-0" />
      <nav className="flex items-center gap-0.5 flex-shrink-0">
        <button onClick={() => onNavigate('chat')} className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all ${isAI ? 'bg-[#fef9f0] text-[#8b6f4e]' : 'text-gray-500 hover:bg-gray-100'}`}>
          <BookOpen size={12} /> Research
        </button>
        <button onClick={() => onNavigate('search')} className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all ${isSearch ? 'bg-[#fef9f0] text-[#8b6f4e]' : 'text-gray-500 hover:bg-gray-100'}`}>
          <Search size={12} /> Cases
        </button>
      </nav>
      {isAI && (
        <>
          <div className="w-px h-5 bg-[#e5e0d8] flex-shrink-0" />
          <div className="flex items-center gap-0.5 flex-shrink-0">
            {AI_MODES.map(m => (
              <button key={m.id} onClick={() => onModeChange(m.id)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all ${aiMode === m.id ? 'bg-[#1a1a2e] text-white' : 'text-gray-500 hover:bg-gray-100'}`}>
                {m.label}
              </button>
            ))}
            {aiMode === 'orchestrate' && (
              <button onClick={onToggleAgents} className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium ml-1 transition-all ${agentsOpen ? 'bg-[#fef9f0] border border-[#e8d5b0] text-[#8b6f4e]' : 'text-gray-500 hover:bg-gray-100'}`}>
                <Users size={11} /> Agents
              </button>
            )}
          </div>
        </>
      )}
      {isSearch && (
        <div className="flex-1 max-w-xl">
          <div className="relative">
            <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input value={searchVal} onChange={e => setSearchVal(e.target.value)} onKeyDown={e => e.key === 'Enter' && onSearch(searchVal)}
              placeholder="Search cases, citations, legal concepts..." className="w-full pl-8 pr-3 py-1.5 text-xs bg-gray-50 border border-[#e5e0d8] rounded-md focus:bg-white focus:outline-none focus:border-[#c8b89a] transition-all" />
          </div>
        </div>
      )}
      <div className="flex-1" />
      <div className="flex items-center gap-2 flex-shrink-0">
        <button onClick={onOpenJurisdiction} className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-[#e5e0d8] text-[10px] text-[#8b6f4e] bg-[#fef9f0] hover:border-[#c8b89a] transition-all max-w-[180px]">
          <span className="truncate">⊞ {jurisdiction}</span>
          <ChevronDown size={9} className="flex-shrink-0" />
        </button>
        {proSe && <span className="text-[9px] bg-[#fef9f0] border border-[#e8d5b0] text-[#8b6f4e] px-1.5 py-0.5 rounded font-medium uppercase tracking-wide flex-shrink-0">Pro Se</span>}
        <button className="p-1.5 rounded hover:bg-gray-100 text-gray-400"><HelpCircle size={14} /></button>
        <button className="p-1.5 rounded hover:bg-gray-100 text-gray-400"><Bell size={14} /></button>
        <div className="relative">
          <button onClick={() => setUserOpen(!userOpen)} className="flex items-center gap-1 pl-1 pr-1.5 py-1 rounded hover:bg-gray-100">
            <div className="w-6 h-6 rounded-full bg-[#1a1a2e] flex items-center justify-center text-white text-xs font-semibold">P</div>
            <ChevronDown size={10} className="text-gray-400" />
          </button>
          {userOpen && (
            <div className="absolute right-0 top-full mt-1 w-44 bg-white rounded-lg shadow-lg border border-[#e5e0d8] py-1 z-50">
              <div className="px-3 py-2 border-b border-[#e5e0d8]"><p className="text-xs font-medium">PJ</p><p className="text-[10px] text-gray-500">Pro Se · TN/AL</p></div>
              <button className="w-full text-left px-3 py-1.5 text-xs text-gray-700 hover:bg-gray-50">Account</button>
              <button className="w-full text-left px-3 py-1.5 text-xs text-gray-700 hover:bg-gray-50">Settings</button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
