import { useState, useRef, useEffect } from 'react';
import { Send, Copy, Check, ThumbsUp, ThumbsDown, RotateCcw, Sparkles } from 'lucide-react';
import { useAnthropicStream } from '../hooks/useAnthropicStream';
import { buildSystemPrompt } from '../data/systemPrompts';
import { RESEARCH_ANSWERS, SAMPLE_QUERIES } from '../data/cases';
import type { Message } from '../types';

interface ChatPageProps {
  mode: 'chat' | 'draft' | 'analyze' | 'orchestrate';
  jurisdiction: string;
  proSe: boolean;
  context: string;
  initialQuery?: string;
  onSelectCase?: (id: string) => void;
}

function ThinkingDots() {
  return (
    <div className="flex items-center gap-1 px-1 py-3">
      {[0, 1, 2].map(i => (
        <div
          key={i}
          className="w-2 h-2 rounded-full bg-[#8b6f4e]"
          style={{ animation: `bounce 1.2s ease-in-out ${i * 0.2}s infinite` }}
        />
      ))}
      <style>{`@keyframes bounce{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-5px)}}`}</style>
    </div>
  );
}

function MessageBlock({ msg }: { msg: Message }) {
  const [copied, setCopied] = useState(false);
  const [thumbs, setThumbs] = useState<'up' | 'down' | null>(null);

  const copy = () => {
    navigator.clipboard.writeText(msg.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const renderContent = (text: string) =>
    text.split('\n').map((line, i) => {
      if (!line.trim()) return <div key={i} className="h-2" />;
      const html = line
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.+?)\*/g, '<em>$1</em>');
      if (line.startsWith('═')) return <hr key={i} className="border-[#e5e0d8] my-2" />;
      if (/^#{1,3}\s/.test(line)) return <h3 key={i} className="font-bold text-sm text-[#1a1a2e] mt-3 mb-1 font-serif"
        dangerouslySetInnerHTML={{ __html: html.replace(/^#+\s/, '') }} />;
      if (/^\d+\.\s/.test(line)) return (
        <div key={i} className="flex gap-2 mb-1 text-sm">
          <span className="text-[#8b6f4e] font-semibold flex-shrink-0">{line.match(/^\d+/)?.[0]}.</span>
          <span dangerouslySetInnerHTML={{ __html: line.replace(/^\d+\.\s*/, '') }} />
        </div>
      );
      if (line.startsWith('- ') || line.startsWith('• ')) return (
        <div key={i} className="flex gap-2 mb-1 text-sm">
          <span className="text-[#8b6f4e] flex-shrink-0 mt-0.5">·</span>
          <span dangerouslySetInnerHTML={{ __html: html.slice(2) }} />
        </div>
      );
      if (line.startsWith('□ ') || line.startsWith('✓ ') || line.startsWith('✅')) return (
        <div key={i} className="flex gap-2 mb-1 text-sm" dangerouslySetInnerHTML={{ __html: html }} />
      );
      return <p key={i} className="text-sm leading-relaxed mb-1"
        style={{ fontFamily: 'Crimson Pro, Georgia, serif', fontSize: '0.97rem', color: '#2d2d2d' }}
        dangerouslySetInnerHTML={{ __html: html }} />;
    });

  if (msg.role === 'user') return (
    <div className="flex justify-end mb-4">
      <div className="max-w-[76%] bg-[#1a1a2e] text-white rounded-2xl rounded-tr-sm px-4 py-2.5 text-sm leading-relaxed">
        {msg.content}
      </div>
    </div>
  );

  return (
    <div className="flex gap-3 mb-5">
      <div className="w-7 h-7 rounded-full bg-[#fef9f0] border border-[#e8d5b0] flex items-center justify-center text-sm flex-shrink-0 mt-0.5">
        ⚖
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[10px] text-[#8b8b8b] mb-1.5">Legal Super-Brain v11.0</div>
        <div className="text-[#2d2d2d]">{renderContent(msg.content)}</div>
        <div className="flex items-center gap-2 mt-2">
          <button onClick={copy} className="flex items-center gap-1 text-[10px] text-[#8b8b8b] hover:text-gray-600 transition-colors">
            {copied ? <Check size={11} /> : <Copy size={11} />}
            {copied ? 'Copied' : 'Copy'}
          </button>
          <button onClick={() => setThumbs('up')} className={`p-1 rounded hover:bg-gray-100 transition-all ${thumbs === 'up' ? 'text-green-600' : 'text-[#8b8b8b]'}`}>
            <ThumbsUp size={11} />
          </button>
          <button onClick={() => setThumbs('down')} className={`p-1 rounded hover:bg-gray-100 transition-all ${thumbs === 'down' ? 'text-red-500' : 'text-[#8b8b8b]'}`}>
            <ThumbsDown size={11} />
          </button>
        </div>
      </div>
    </div>
  );
}

const MODE_META = {
  chat: {
    icon: '✦', label: 'AI Research', color: '#8b6f4e',
    placeholder: 'Ask questions about case law, statutes, and regulations...',
    exampleLabel: 'Try Chat Example',
    examples: SAMPLE_QUERIES,
  },
  draft: {
    icon: '✍', label: 'Drafting', color: '#1e3a5f',
    placeholder: 'Describe the legal document you need — motion, brief, memorandum...',
    exampleLabel: 'Try Drafting',
    examples: [
      'Draft a Motion to Modify Parenting Plan in Davidson County, TN. Father (pro se). Child is 8. Mother relocated 90 miles without required 60-day notice per T.C.A. § 36-6-108.',
      'Draft a Rule 60.02(3) Motion for Relief from Judgment based on fraud on the court — opposing party concealed insurance policy modification during statutory injunction period.',
      'Draft a Motion to Dismiss for lack of subject matter jurisdiction — OP extension entered via nunc pro tunc 254 days after statutory deadline.',
    ],
  },
  analyze: {
    icon: '⚗', label: 'Analyze', color: '#7c3aed',
    placeholder: 'Paste transcript text, hearing notes, or document to analyze for the 37-trigger forensic pipeline...',
    exampleLabel: 'Try Analyze',
    examples: [
      'JUDGE: "The order of protection is in place between you all and has always been in place." [Analyze this statement — OP was vacated by Court of Appeals 8 months prior.]',
      'Paste your hearing transcript below. I will run the full 6-stage forensic pipeline and evaluate all 37 sub-triggers.',
    ],
  },
  orchestrate: {
    icon: '⚙', label: 'Orchestrate', color: '#059669',
    placeholder: 'Paste a prompt to score/enhance, or describe the agent team task...',
    exampleLabel: 'Try Orchestrate',
    examples: [
      'Score and enhance: "Analyze the hearing transcript and find any legal problems."',
      'Activate the agent team: Build a full-stack legal case management system with React frontend, Node.js backend, PostgreSQL, CI/CD.',
    ],
  },
};

export default function ChatPage({ mode, jurisdiction, proSe, context, initialQuery, onSelectCase }: ChatPageProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState(initialQuery || '');
  const outputRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const systemPrompt = buildSystemPrompt(mode, { jurisdiction, proSe, context });
  const { stream, streaming, streamText } = useAnthropicStream({ systemPrompt });

  useEffect(() => {
    if (outputRef.current) outputRef.current.scrollTop = outputRef.current.scrollHeight;
  }, [messages, streamText]);

  const send = async (text: string = input) => {
    if (!text.trim() || streaming) return;
    const userMsg: Message = { role: 'user', content: text };
    const updated = [...messages, userMsg];
    setMessages(updated);
    setInput('');

    try {
      const reply = await stream(updated);
      if (reply) setMessages(prev => [...prev, { role: 'assistant', content: reply }]);
    } catch (err) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `⚠️ Error: ${(err as Error).message}. Please try again.`,
      }]);
    }
  };

  const reset = () => { setMessages([]); setInput(''); };
  const meta = MODE_META[mode];

  return (
    <div className="flex flex-col h-full overflow-hidden bg-[#f8f7f4]">
      {/* Messages */}
      <div ref={outputRef} className="flex-1 overflow-y-auto px-6 py-5">
        {messages.length === 0 && !streaming && (
          <div className="max-w-2xl mx-auto pt-6">
            {/* Hero */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium border mb-4"
                style={{ background: '#fef9f0', borderColor: '#e8d5b0', color: '#8b6f4e' }}>
                <Sparkles size={11} /> {meta.label}
              </div>
              <h1 className="text-[2rem] font-medium leading-tight text-[#1a1a2e] mb-2"
                style={{ fontFamily: 'Crimson Pro, Georgia, serif' }}>
                {mode === 'chat' && 'Legal research that thinks with you'}
                {mode === 'draft' && 'Draft with Scalia/Garner precision'}
                {mode === 'analyze' && 'Forensic analysis — 37 triggers, 6 stages'}
                {mode === 'orchestrate' && 'POML orchestration + Agent team'}
              </h1>
              <p className="text-sm text-[#6b5a4a] max-w-lg mx-auto leading-relaxed">
                {mode === 'chat' && 'Case law, statutes, and legal standards with full Bluebook citations.'}
                {mode === 'draft' && 'CRAC/CREAC motions, briefs, memoranda with 6-pass multi-persona review.'}
                {mode === 'analyze' && 'Transcript → forensic linguistics → IRAC → 37-trigger flagging → 11-section report.'}
                {mode === 'orchestrate' && 'Transform prompts to POML specifications. Score Before/After. Deploy agent team.'}
              </p>
            </div>

            {/* Example queries */}
            <div className="bg-white border border-[#e5e0d8] rounded-xl p-4">
              <p className="text-[10px] text-[#8b8b8b] uppercase tracking-widest mb-3">{meta.exampleLabel}</p>
              {meta.examples.map((q, i) => (
                <button key={i} onClick={() => send(q)}
                  className="w-full text-left px-3 py-2.5 rounded-lg border border-[#e5e0d8] bg-[#f8f7f4] hover:bg-[#fef9f0] hover:border-[#e8d5b0] transition-all mb-2 text-xs text-[#5a4a3a] leading-relaxed">
                  <span className="text-[#8b6f4e] mr-1.5">{meta.icon}</span>
                  {q.slice(0, 120)}{q.length > 120 ? '...' : ''}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) => <MessageBlock key={i} msg={m} />)}

        {streaming && streamText && (
          <div className="flex gap-3 mb-5">
            <div className="w-7 h-7 rounded-full bg-[#fef9f0] border border-[#e8d5b0] flex items-center justify-center text-sm flex-shrink-0 mt-0.5">⚖</div>
            <div className="flex-1">
              <div className="text-[10px] text-[#8b8b8b] mb-1.5">Legal Super-Brain v11.0 · streaming...</div>
              <div className="text-sm leading-relaxed text-[#2d2d2d] whitespace-pre-wrap"
                style={{ fontFamily: 'Crimson Pro, Georgia, serif', fontSize: '0.97rem' }}>
                {streamText}
                <span className="inline-block w-0.5 h-4 bg-[#8b6f4e] ml-0.5 align-middle animate-pulse" />
              </div>
            </div>
          </div>
        )}
        {streaming && !streamText && (
          <div className="flex gap-3">
            <div className="w-7 h-7 rounded-full bg-[#fef9f0] border border-[#e8d5b0] flex items-center justify-center text-sm flex-shrink-0">⚖</div>
            <ThinkingDots />
          </div>
        )}
      </div>

      {/* Input */}
      <div className="border-t border-[#e5e0d8] bg-white px-6 py-3">
        {messages.length > 0 && (
          <div className="flex items-center gap-2 mb-2">
            <button onClick={reset} className="flex items-center gap-1.5 text-[10px] text-[#8b8b8b] hover:text-gray-600 transition-colors">
              <RotateCcw size={10} /> New conversation
            </button>
          </div>
        )}
        <div className="border border-[#e5e0d8] rounded-xl bg-white overflow-hidden shadow-sm">
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder={meta.placeholder}
            rows={3}
            className="w-full bg-transparent border-none resize-none text-sm text-[#1a1a2e] outline-none px-4 pt-3 pb-1 leading-relaxed placeholder:text-[#b8a890]"
          />
          <div className="flex items-center justify-between px-4 pb-2.5">
            <span className="text-[10px] text-[#b8a890]">↵ Enter to send · Shift+↵ for new line</span>
            <button
              onClick={() => send()}
              disabled={streaming || !input.trim()}
              className="w-8 h-8 rounded-full flex items-center justify-center text-white transition-all disabled:opacity-30 disabled:cursor-not-allowed"
              style={{ background: streaming || !input.trim() ? '#e5e0d8' : '#1a1a2e' }}
            >
              {streaming
                ? <div className="w-3 h-3 border-2 border-[#8b8b8b] border-t-transparent rounded-full animate-spin" />
                : <Send size={13} />
              }
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
