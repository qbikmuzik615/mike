import React from "react";
import { FRAMEWORK_VERSION, FRAMEWORK_DATE } from "../data/frameworkData";

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-white/5 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center text-sm">
                🤖
              </div>
              <div>
                <div className="font-bold text-white text-xs font-mono">DIGITAL SOFTWARE AGENCY</div>
                <div className="text-[10px] text-purple-400 font-mono">v{FRAMEWORK_VERSION} · {FRAMEWORK_DATE}</div>
              </div>
            </div>
            <p className="text-xs text-gray-500 leading-relaxed">
              The world's most advanced multi-agent AI orchestration framework for full-stack development.
              Built by a 50-year prompt engineering veteran.
            </p>
          </div>

          {/* Agents */}
          <div>
            <div className="text-xs font-mono font-semibold text-gray-500 mb-3">AGENT ROSTER</div>
            <div className="space-y-1.5">
              {["🎯 Project Manager", "🎨 UI/UX Architect", "⚛️ Frontend Engineer", "⚙️ Backend Engineer", "🗄️ DB Schema Architect", "🛡️ DevOps / QA Lead"].map((a) => (
                <div key={a} className="text-xs text-gray-400 font-mono">{a}</div>
              ))}
            </div>
          </div>

          {/* Quality gates */}
          <div>
            <div className="text-xs font-mono font-semibold text-gray-500 mb-3">QUALITY MANDATES</div>
            <div className="space-y-1.5">
              {[
                "✅ Test Coverage ≥ 85%",
                "✅ Lighthouse Score ≥ 95",
                "✅ Zero Critical CVEs",
                "✅ WCAG 2.2 AA Compliant",
                "✅ OWASP Top 10 Mitigated",
                "✅ OpenAPI 3.1 Contracts",
                "✅ Zero N+1 Query Issues",
              ].map((g) => (
                <div key={g} className="text-xs text-gray-400 font-mono">{g}</div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/5 pt-6 flex flex-wrap items-center justify-between gap-4">
          <div className="text-[10px] font-mono text-gray-600">
            Enhanced Multi-Agent Full-Stack Development Framework v{FRAMEWORK_VERSION} · Status: PRODUCTION READY · 
            Built with: React 18 + TypeScript + TailwindCSS
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
              <span className="text-[10px] font-mono text-emerald-400">ALL AGENTS OPERATIONAL</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
