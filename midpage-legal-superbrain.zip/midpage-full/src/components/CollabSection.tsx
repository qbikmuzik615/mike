import React, { useState } from "react";
import { COLLAB_QUESTIONS } from "../data/frameworkData";

const categoryColors: Record<string, { accent: string; bg: string; border: string; tag: string }> = {
  "Scale & Complexity": { accent: "text-purple-400", bg: "bg-purple-900/20", border: "border-purple-500/30", tag: "bg-purple-500/15 text-purple-300 border-purple-500/20" },
  "Compliance & Security": { accent: "text-red-400", bg: "bg-red-900/20", border: "border-red-500/30", tag: "bg-red-500/15 text-red-300 border-red-500/20" },
  "AI & Integration": { accent: "text-cyan-400", bg: "bg-cyan-900/20", border: "border-cyan-500/30", tag: "bg-cyan-500/15 text-cyan-300 border-cyan-500/20" },
  "Team & Workflow": { accent: "text-emerald-400", bg: "bg-emerald-900/20", border: "border-emerald-500/30", tag: "bg-emerald-500/15 text-emerald-300 border-emerald-500/20" },
  "Performance & UX": { accent: "text-yellow-400", bg: "bg-yellow-900/20", border: "border-yellow-500/30", tag: "bg-yellow-500/15 text-yellow-300 border-yellow-500/20" },
};

const ALL_CATEGORIES = ["All", "Scale & Complexity", "Compliance & Security", "AI & Integration", "Team & Workflow", "Performance & UX"];

export const CollabSection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const [answeredQuestions, setAnsweredQuestions] = useState<Record<number, string>>({});
  const [currentInput, setCurrentInput] = useState<Record<number, string>>({});
  const [expandedQuestion, setExpandedQuestion] = useState<number | null>(null);
  const [showCompletionMessage, setShowCompletionMessage] = useState(false);

  const filtered = activeCategory === "All"
    ? COLLAB_QUESTIONS
    : COLLAB_QUESTIONS.filter((q) => q.category === activeCategory);

  const answeredCount = Object.keys(answeredQuestions).length;
  const totalCount = COLLAB_QUESTIONS.length;

  const handleAnswer = (id: number) => {
    const answer = currentInput[id]?.trim();
    if (!answer) return;
    setAnsweredQuestions((prev) => ({ ...prev, [id]: answer }));
    setCurrentInput((prev) => ({ ...prev, [id]: "" }));
    setExpandedQuestion(null);
    if (answeredCount + 1 >= totalCount) setShowCompletionMessage(true);
  };

  const handleKeyDown = (e: React.KeyboardEvent, id: number) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleAnswer(id);
  };

  return (
    <section id="collab" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center mb-14">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-4">
          <span className="text-xs font-mono text-cyan-400 font-semibold">PHASE 0 — PROJECT MANAGER ACTIVATED</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">
          Collaborative{" "}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">
            Requirement Extraction
          </span>
        </h2>
        <p className="text-gray-400 max-w-2xl mx-auto text-sm leading-relaxed">
          The Project Manager agent will not propose a solution until all ambiguities are resolved.
          Answer these 12 strategic questions to configure your personalized Digital Software Agency.
          Each answer activates specific agents, modules, and compliance templates.
        </p>
      </div>

      {/* Progress */}
      <div className="mb-8 p-5 rounded-2xl bg-gray-900/50 border border-white/8">
        <div className="flex items-center justify-between mb-3">
          <div>
            <span className="text-sm font-bold text-white">Requirements Extracted</span>
            <span className="ml-2 text-xs text-gray-500 font-mono">({answeredCount}/{totalCount} questions answered)</span>
          </div>
          <span className={`text-sm font-mono font-bold ${answeredCount === totalCount ? "text-emerald-400" : "text-purple-400"}`}>
            {answeredCount === totalCount ? "✅ COMPLETE" : `${Math.round((answeredCount / totalCount) * 100)}%`}
          </span>
        </div>
        <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-purple-500 to-cyan-500 transition-all duration-500"
            style={{ width: `${(answeredCount / totalCount) * 100}%` }}
          />
        </div>
      </div>

      {/* PM persona box */}
      <div className="mb-8 p-5 rounded-2xl bg-purple-900/20 border border-purple-500/30">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-xl flex-shrink-0">
            🎯
          </div>
          <div>
            <div className="text-xs font-mono text-purple-400 font-semibold mb-1">PROJECT_MANAGER → REQUIREMENT_EXTRACTION_MODE</div>
            <p className="text-sm text-gray-300 leading-relaxed">
              "Acting as your Senior Project Manager, I will not propose a solution or assemble your team until we deeply understand what you're building. The following questions use structured Q&A to extract your user stories, technical constraints, compliance requirements, and integration needs. Your answers determine which of our 6 specialist agents are activated and at what intensity. Let's build exactly what you envision."
            </p>
          </div>
        </div>
      </div>

      {/* Category filter */}
      <div className="flex flex-wrap gap-2 mb-8">
        {ALL_CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold border transition-all duration-200 ${
              activeCategory === cat
                ? "bg-purple-500/20 border-purple-500/40 text-purple-300"
                : "bg-white/3 border-white/8 text-gray-500 hover:text-gray-300 hover:bg-white/5"
            }`}
          >
            {cat}
            {cat !== "All" && (
              <span className="ml-1.5 opacity-60">
                ({COLLAB_QUESTIONS.filter((q) => q.category === cat).length})
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Questions */}
      <div className="space-y-3">
        {filtered.map((q) => {
          const c = categoryColors[q.category] || categoryColors["Scale & Complexity"];
          const isAnswered = !!answeredQuestions[q.id];
          const isExpanded = expandedQuestion === q.id;

          return (
            <div
              key={q.id}
              className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                isAnswered
                  ? "bg-emerald-900/10 border-emerald-500/20"
                  : isExpanded
                  ? `${c.bg} ${c.border}`
                  : "bg-gray-900/30 border-white/5 hover:border-white/10"
              }`}
            >
              <button
                className="w-full text-left px-5 py-4"
                onClick={() => setExpandedQuestion(isExpanded ? null : q.id)}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-base flex-shrink-0 ${isAnswered ? "bg-emerald-500/20" : c.bg} border ${isAnswered ? "border-emerald-500/30" : c.border}`}>
                    {isAnswered ? "✅" : q.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${c.tag}`}>
                        {q.category}
                      </span>
                      <span className="text-[10px] font-mono text-gray-600">Q{q.id.toString().padStart(2, "0")}</span>
                    </div>
                    <p className="text-sm font-semibold text-white leading-snug">{q.question}</p>
                    {isAnswered && (
                      <div className="mt-2 flex items-start gap-2">
                        <span className="text-emerald-400 text-xs flex-shrink-0">→</span>
                        <span className="text-xs text-emerald-300 font-mono leading-relaxed">{answeredQuestions[q.id]}</span>
                      </div>
                    )}
                  </div>
                  <span className={`text-xs font-mono transition-transform duration-200 flex-shrink-0 ${isExpanded ? "rotate-180 " + c.accent : "text-gray-600"}`}>
                    ▼
                  </span>
                </div>
              </button>

              {isExpanded && !isAnswered && (
                <div className="px-5 pb-5 space-y-4 border-t border-white/5">
                  {/* Why this matters */}
                  <div className={`pt-4 p-4 rounded-xl ${c.bg} border ${c.border}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-yellow-400 text-xs font-mono font-bold">§§</span>
                      <span className={`text-xs font-mono font-semibold ${c.accent}`}>WHY THIS MATTERS</span>
                    </div>
                    <p className="text-xs text-gray-300 leading-relaxed">{q.purpose}</p>
                  </div>

                  {/* Answer input */}
                  <div>
                    <label className="text-xs font-mono text-gray-500 mb-2 block">YOUR ANSWER (Cmd/Ctrl+Enter to submit)</label>
                    <textarea
                      className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-600 font-mono focus:outline-none focus:border-purple-500/50 focus:ring-1 focus:ring-purple-500/20 resize-none transition-all duration-200"
                      placeholder="Type your answer here..."
                      rows={3}
                      value={currentInput[q.id] || ""}
                      onChange={(e) => setCurrentInput((prev) => ({ ...prev, [q.id]: e.target.value }))}
                      onKeyDown={(e) => handleKeyDown(e, q.id)}
                    />
                    <button
                      onClick={() => handleAnswer(q.id)}
                      disabled={!currentInput[q.id]?.trim()}
                      className={`mt-2 px-5 py-2.5 rounded-xl text-xs font-mono font-bold transition-all duration-200 ${
                        currentInput[q.id]?.trim()
                          ? `${c.bg} ${c.border} border ${c.accent} hover:opacity-90`
                          : "bg-gray-800 text-gray-600 cursor-not-allowed border border-white/5"
                      }`}
                    >
                      Submit Answer →
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Completion message */}
      {showCompletionMessage && (
        <div className="mt-8 p-6 rounded-2xl bg-gradient-to-r from-purple-900/40 to-cyan-900/40 border border-purple-500/30 shadow-2xl shadow-purple-500/10">
          <div className="flex items-start gap-4">
            <div className="text-4xl">🚀</div>
            <div>
              <div className="text-xs font-mono text-purple-400 font-semibold mb-1">PROJECT_MANAGER → TEAM_ASSEMBLY_INITIATED</div>
              <h3 className="text-lg font-black text-white mb-2">
                Requirements Extracted Successfully!
              </h3>
              <p className="text-sm text-gray-300 leading-relaxed mb-4">
                "All requirements are now unambiguous. Team assembled. Initiating architectural design phase.
                Loading expert personas for all relevant specialist agents based on your project profile.
                Stand by for ASCII mockup generation and MermaidJS architecture diagram."
              </p>
              <div className="flex flex-wrap gap-2">
                {["🎯 PM", "🎨 UX Architect", "⚛️ Frontend Eng", "⚙️ Backend Eng", "🗄️ DB Architect", "🛡️ DevOps/QA"].map((a) => (
                  <span key={a} className="text-xs font-mono px-3 py-1.5 rounded-full bg-purple-500/20 border border-purple-500/30 text-purple-300">
                    {a}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Reasoning note */}
      <div className="mt-8 p-5 rounded-2xl bg-gray-950/60 border border-white/5">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-yellow-400 text-sm font-mono font-bold">§§</span>
          <span className="text-xs font-mono font-bold text-yellow-400">REASONING: WHY 12 QUESTIONS?</span>
        </div>
        <p className="text-sm text-gray-400 leading-relaxed">
          These 12 questions map directly to agent activation thresholds. Scale/Complexity answers configure the
          DevOps agent's IaC choices and DB agent's partitioning strategy. Compliance answers activate specialist
          security agents and modify the OWASP audit scope. AI/Integration answers load the AI_INTEGRATION_SPECIALIST
          persona with model routing and MCP client configurations. Team/Workflow answers determine documentation
          depth and CI/CD branch strategy. Performance/UX answers set concrete Lighthouse thresholds and accessibility
          compliance levels. No question is decorative — each answer mutates the framework configuration.
        </p>
      </div>
    </section>
  );
};
