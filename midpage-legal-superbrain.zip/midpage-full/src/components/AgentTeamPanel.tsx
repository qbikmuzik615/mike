import { useState } from 'react';
import { ChevronDown, ChevronUp, Copy, Check } from 'lucide-react';
import { AGENTS } from '../data/frameworkData';

export default function AgentTeamPanel() {
  const [expanded, setExpanded] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const copyTrigger = (trigger: string, id: string) => {
    navigator.clipboard.writeText(trigger);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="border border-[#e5e0d8] rounded-xl bg-white overflow-hidden">
      <div className="px-4 py-2.5 border-b border-[#e5e0d8] flex items-center justify-between">
        <span className="text-xs font-semibold text-[#1a1a2e]">⚙ Agent Team — Digital Software Agency</span>
        <span className="text-[10px] text-[#8b8b8b]">{AGENTS.length} agents operational</span>
      </div>
      <div className="grid grid-cols-2 gap-0 divide-x divide-y divide-[#e5e0d8]">
        {AGENTS.map(agent => (
          <div key={agent.id} className="p-3">
            <div className="flex items-start justify-between gap-2 mb-1.5">
              <div className="flex items-center gap-2">
                <span className="text-base">{agent.icon}</span>
                <div>
                  <p className="text-xs font-semibold text-[#1a1a2e] leading-tight">{agent.name}</p>
                  <code
                    className="text-[10px] font-mono cursor-pointer hover:opacity-80 transition-opacity"
                    style={{ color: agent.color }}
                    onClick={() => copyTrigger(agent.trigger, agent.id)}
                  >
                    {agent.trigger}
                    {copied === agent.id
                      ? <Check size={9} className="inline ml-1 text-green-500" />
                      : <Copy size={9} className="inline ml-1 opacity-40" />
                    }
                  </code>
                </div>
              </div>
              <button
                onClick={() => setExpanded(expanded === agent.id ? null : agent.id)}
                className="text-gray-400 hover:text-gray-600 transition-colors flex-shrink-0"
              >
                {expanded === agent.id ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
              </button>
            </div>

            <p className="text-[10px] text-[#8b8b8b] leading-relaxed">
              {agent.description.slice(0, 80)}...
            </p>

            {expanded === agent.id && (
              <div className="mt-2 pt-2 border-t border-[#e5e0d8]">
                <div className="mb-1.5">
                  <p className="text-[10px] font-semibold text-[#5a4a3a] mb-1">Jargon</p>
                  <div className="flex flex-wrap gap-1">
                    {agent.jargon.slice(0, 5).map(j => (
                      <span key={j} className="text-[9px] px-1.5 py-0.5 rounded border border-[#e5e0d8] text-[#8b6f4e] bg-[#fef9f0]">
                        {j}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-[10px] font-semibold text-[#5a4a3a] mb-1">Integration Contract</p>
                  <p className="text-[10px] text-[#8b8b8b] leading-relaxed">{agent.integrationContract}</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
