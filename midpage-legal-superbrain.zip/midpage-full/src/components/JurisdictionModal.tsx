import { useState } from 'react';
import { X } from 'lucide-react';
import { STATE_JURISDICTIONS, FEDERAL_CIRCUITS, OTHER_FEDERAL, JURISDICTION_PRESETS } from '../data/jurisdictions';
import type { JurisdictionSelection } from '../types';

interface JurisdictionModalProps {
  selected: JurisdictionSelection;
  onClose: () => void;
  onApply: (sel: JurisdictionSelection) => void;
}

export default function JurisdictionModal({ selected, onClose, onApply }: JurisdictionModalProps) {
  const [sel, setSel] = useState<JurisdictionSelection>({ ...selected });
  const [docType, setDocType] = useState<'cases' | 'statutes'>('cases');

  const toggle = (cat: keyof JurisdictionSelection, val: string) => {
    setSel(prev => ({
      ...prev,
      [cat]: prev[cat].includes(val)
        ? prev[cat].filter(x => x !== val)
        : [...prev[cat], val],
    }));
  };

  const selectAll = (cat: keyof JurisdictionSelection, vals: string[]) =>
    setSel(prev => ({ ...prev, [cat]: [...vals] }));

  const clearAll = (cat: keyof JurisdictionSelection) =>
    setSel(prev => ({ ...prev, [cat]: [] }));

  const applyPreset = (key: keyof typeof JURISDICTION_PRESETS) => {
    const p = JURISDICTION_PRESETS[key];
    setSel({ state: p.state, federal: p.federal, other: p.other });
  };

  const totalSelected = sel.state.length + sel.federal.length + sel.other.length;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/30"
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <div className="bg-white rounded-xl border border-[#e5e0d8] w-[740px] max-h-[82vh] flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#e5e0d8]">
          <div className="flex gap-2">
            <button
              onClick={() => setDocType('cases')}
              className={`px-4 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                docType === 'cases'
                  ? 'bg-[#fef9f0] border-[#e8d5b0] text-[#8b6f4e]'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Cases
            </button>
            <button
              onClick={() => setDocType('statutes')}
              className={`px-4 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                docType === 'statutes'
                  ? 'bg-[#fef9f0] border-[#e8d5b0] text-[#8b6f4e]'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Constitutions, Statutes, & Regulations
              <span className="ml-2 text-[10px] bg-[#e5e0d8] px-1.5 py-0.5 rounded">Beta</span>
            </button>
          </div>
          <div className="flex items-center gap-2">
            {/* Quick presets */}
            <div className="flex gap-1">
              {Object.entries(JURISDICTION_PRESETS).map(([key, p]) => (
                <button
                  key={key}
                  onClick={() => applyPreset(key as keyof typeof JURISDICTION_PRESETS)}
                  className="px-2 py-1 text-[10px] rounded border border-[#e5e0d8] text-[#8b6f4e] hover:bg-[#fef9f0] transition-all"
                >
                  {p.label}
                </button>
              ))}
            </div>
            <div className="w-px h-5 bg-[#e5e0d8]" />
            <span className="text-xs text-gray-400">{totalSelected} selected</span>
            <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded transition-all">
              <X size={15} className="text-gray-400" />
            </button>
          </div>
        </div>

        {/* Three-column grid */}
        <div className="flex flex-1 overflow-hidden divide-x divide-[#e5e0d8]">
          {/* State */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="px-4 py-2 border-b border-[#e5e0d8] flex items-center justify-between">
              <div>
                <h3 className="text-xs font-semibold text-[#1a1a2e]">State</h3>
                <p className="text-[10px] text-[#8b8b8b] mt-0.5">All binding appellate-level cases for 50 states.</p>
              </div>
              <div className="flex items-center gap-3 text-[10px]">
                <span className="text-[#8b8b8b]">{sel.state.length} selected</span>
                <button onClick={() => selectAll('state', STATE_JURISDICTIONS)} className="text-blue-500 hover:underline">Select All</button>
                <span className="text-[#e5e0d8]">|</span>
                <button onClick={() => clearAll('state')} className="text-[#8b8b8b] hover:text-gray-700">Clear</button>
              </div>
            </div>
            <div className="overflow-y-auto flex-1 p-2">
              {STATE_JURISDICTIONS.map(s => (
                <label key={s} className="flex items-center gap-2 px-2 py-1 rounded cursor-pointer hover:bg-gray-50 transition-all">
                  <input
                    type="checkbox"
                    checked={sel.state.includes(s)}
                    onChange={() => toggle('state', s)}
                    className="accent-[#8b6f4e] w-3.5 h-3.5"
                  />
                  <span className="text-xs text-[#1a1a2e]">{s}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Federal */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="px-4 py-2 border-b border-[#e5e0d8] flex items-center justify-between">
              <div>
                <h3 className="text-xs font-semibold text-[#1a1a2e]">Federal</h3>
                <p className="text-[10px] text-[#8b8b8b] mt-0.5">Federal appellate, district, and bankruptcy courts.</p>
              </div>
              <div className="flex items-center gap-3 text-[10px]">
                <span className="text-[#8b8b8b]">{sel.federal.length} selected</span>
                <button onClick={() => selectAll('federal', FEDERAL_CIRCUITS)} className="text-blue-500 hover:underline">Select All</button>
                <span className="text-[#e5e0d8]">|</span>
                <button onClick={() => clearAll('federal')} className="text-[#8b8b8b] hover:text-gray-700">Clear</button>
              </div>
            </div>
            <div className="overflow-y-auto flex-1 p-2">
              {FEDERAL_CIRCUITS.map(f => (
                <label key={f} className="flex items-center gap-2 px-2 py-1 rounded cursor-pointer hover:bg-gray-50 transition-all">
                  <input
                    type="checkbox"
                    checked={sel.federal.includes(f)}
                    onChange={() => toggle('federal', f)}
                    className="accent-[#8b6f4e] w-3.5 h-3.5"
                  />
                  <span className="text-xs text-[#1a1a2e]">{f}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Other Federal */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="px-4 py-2 border-b border-[#e5e0d8] flex items-center justify-between">
              <div>
                <h3 className="text-xs font-semibold text-[#1a1a2e]">Other Federal Jurisdictions</h3>
                <p className="text-[10px] text-[#8b8b8b] mt-0.5">All written opinions for federal jurisdictions.</p>
              </div>
              <button onClick={() => clearAll('other')} className="text-[10px] text-[#8b8b8b] hover:text-gray-700">Clear</button>
            </div>
            <div className="overflow-y-auto flex-1 p-2">
              {OTHER_FEDERAL.map(o => (
                <label key={o} className="flex items-center gap-2 px-2 py-1 rounded cursor-pointer hover:bg-gray-50 transition-all">
                  <input
                    type="checkbox"
                    checked={sel.other.includes(o)}
                    onChange={() => toggle('other', o)}
                    className="accent-[#8b6f4e] w-3.5 h-3.5"
                  />
                  <span className="text-xs text-[#1a1a2e]">{o}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-[#e5e0d8]">
          <p className="text-xs text-[#8b8b8b]">
            {totalSelected === 0 ? 'No jurisdictions selected — all will be searched' : `${totalSelected} jurisdiction${totalSelected > 1 ? 's' : ''} selected`}
          </p>
          <div className="flex gap-2">
            <button onClick={onClose} className="px-4 py-1.5 text-xs border border-[#e5e0d8] rounded-lg text-gray-600 hover:bg-gray-50 transition-all">
              Cancel
            </button>
            <button
              onClick={() => { onApply(sel); onClose(); }}
              className="px-4 py-1.5 text-xs bg-[#1a1a2e] text-white rounded-lg font-medium hover:bg-[#2a2a3e] transition-all"
            >
              Apply
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
