import { useState } from 'react';
import { Scale, Plus, Bookmark, AlignLeft, Settings, HelpCircle, History } from 'lucide-react';
import { ALL_CASES } from '../data/cases';
import type { Thread, View } from '../types';

interface SidebarProps {
  view: View;
  threads: Thread[];
  savedCases: string[];
  context: string;
  proSe: boolean;
  onNewThread: () => void;
  onLoadThread: (thread: Thread) => void;
  onSetContext: (ctx: string) => void;
  onToggleProSe: () => void;
  onNavigate: (view: View) => void;
  activeThreadId?: number;
}

export default function Sidebar({
  view, threads, savedCases, context, proSe,
  onNewThread, onLoadThread, onSetContext, onToggleProSe, onNavigate, activeThreadId,
}: SidebarProps) {
  const [contextOpen, setContextOpen] = useState(false);
  const [savedOpen, setSavedOpen] = useState(true);

  return (
    <aside className="w-[220px] flex-shrink-0 border-r border-[#e5e0d8] flex flex-col bg-[#f3f1ed]">
      {/* Logo */}
      <div className="px-3.5 py-3 border-b border-[#ede8e0]">
        <button onClick={() => onNavigate('home')} className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-md flex items-center justify-center bg-[#1a1a2e]">
            <Scale size={13} className="text-white" />
          </div>
          <div>
            <div className="font-semibold text-[1.05rem] leading-tight text-[#1a1a2e]" style={{ fontFamily: 'Crimson Pro, Georgia, serif' }}>
              midpage
            </div>
            <div className="text-[9px] text-[#8b8b8b] tracking-widest uppercase leading-none">
              Legal Super-Brain v11
            </div>
          </div>
        </button>
      </div>

      {/* New Thread */}
      <div className="px-2.5 py-2">
        <button
          onClick={onNewThread}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-lg border border-[#e5e0d8] text-xs font-medium text-[#1a1a2e] hover:bg-white transition-all"
        >
          <Plus size={13} />
          New Thread
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-2.5 pb-3 space-y-0.5">
        {/* Saved Cases */}
        <div className="mb-2">
          <button
            onClick={() => setSavedOpen(!savedOpen)}
            className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs text-[#5a4a3a] hover:bg-white transition-all"
          >
            <Bookmark size={12} />
            Saved Cases
            <span className="ml-auto text-[10px] bg-[#fef9f0] border border-[#e8d5b0] text-[#8b6f4e] px-1.5 py-0.5 rounded">
              {savedCases.length}
            </span>
          </button>
          {savedOpen && savedCases.map(id => {
            const c = ALL_CASES.find(x => x.id === id);
            if (!c) return null;
            return (
              <button
                key={id}
                onClick={() => onNavigate('case')}
                className="w-full text-left px-5 py-1.5 rounded hover:bg-white transition-all"
              >
                <p className="text-[11px] text-[#5a4a3a] leading-tight font-medium truncate">{c.shortName}</p>
                <p className="text-[9px] text-[#8b8b8b]">{c.citation}</p>
              </button>
            );
          })}
        </div>

        {/* Context */}
        <div className="mb-2">
          <button
            onClick={() => setContextOpen(!contextOpen)}
            className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs text-[#5a4a3a] transition-all ${
              contextOpen ? 'bg-white border border-[#e5e0d8]' : 'hover:bg-white'
            }`}
          >
            <AlignLeft size={12} />
            Context
            {context && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-[#8b6f4e]" />}
            <span className="text-[9px] text-[#8b8b8b] ml-auto">{contextOpen ? '▴' : '▾'}</span>
          </button>
          {contextOpen && (
            <div className="mx-1 mt-1 p-2.5 bg-white border border-[#e5e0d8] rounded-lg">
              <p className="text-[9px] text-[#8b8b8b] mb-1.5">Background facts injected into all AI requests</p>
              <textarea
                value={context}
                onChange={e => onSetContext(e.target.value)}
                placeholder="Type in background facts to give the AI context about what you're researching..."
                className="w-full min-h-[70px] text-[11px] text-[#1a1a2e] bg-transparent border-none resize-none outline-none leading-relaxed placeholder:text-[#b8a890]"
              />
              {context && (
                <p className="text-[9px] text-[#8b8b8b] text-right">{context.length} chars</p>
              )}
            </div>
          )}
        </div>

        {/* Pro Se toggle */}
        <div className="px-2.5 py-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-[#5a4a3a]">Pro Se Mode</span>
            <button
              onClick={onToggleProSe}
              className={`w-9 h-5 rounded-full relative transition-colors duration-200 ${proSe ? 'bg-[#8b6f4e]' : 'bg-[#d4c9b8]'}`}
            >
              <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all duration-200 ${proSe ? 'left-[18px]' : 'left-0.5'}`} />
            </button>
          </div>
          {proSe && (
            <p className="text-[9px] text-[#8b6f4e] mt-0.5">Certificate of Service included in drafts</p>
          )}
        </div>

        {/* History */}
        <div className="mt-3">
          <div className="flex items-center gap-1.5 px-2.5 py-1">
            <History size={10} className="text-[#8b8b8b]" />
            <p className="text-[9px] text-[#8b8b8b] uppercase tracking-widest">History</p>
          </div>
          {threads.length === 0 ? (
            <p className="text-[11px] text-[#8b8b8b] px-3 py-1">No items yet</p>
          ) : (
            threads.map(t => (
              <button
                key={t.id}
                onClick={() => onLoadThread(t)}
                className={`w-full text-left px-3 py-2 rounded-lg transition-all mb-0.5 ${
                  activeThreadId === t.id ? 'bg-white border border-[#e5e0d8]' : 'hover:bg-white'
                }`}
              >
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="text-[9px] bg-[#fef9f0] border border-[#e8d5b0] text-[#8b6f4e] px-1.5 py-0.5 rounded font-medium uppercase tracking-wide">
                    {t.mode}
                  </span>
                </div>
                <p className="text-[11px] text-[#5a4a3a] leading-snug truncate">{t.title}</p>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-[#ede8e0] px-3.5 py-2.5">
        <button className="flex items-center gap-2 text-[11px] text-[#5a4a3a] hover:text-[#1a1a2e] py-1 w-full transition-colors">
          <HelpCircle size={12} /> Support
        </button>
        <button className="flex items-center gap-2 text-[11px] text-[#5a4a3a] hover:text-[#1a1a2e] py-1 w-full transition-colors">
          <Settings size={12} /> Account
        </button>
        <div className="flex items-center justify-between mt-1.5">
          <span className="text-[11px] text-[#5a4a3a] font-medium" style={{ fontFamily: 'Crimson Pro, Georgia, serif' }}>midpage</span>
          <span className="text-[9px] text-[#8b8b8b]">⊞</span>
        </div>
      </div>
    </aside>
  );
}
