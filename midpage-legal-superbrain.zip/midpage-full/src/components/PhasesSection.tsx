import React, { useState } from "react";
import { PHASES, AGENTS, COMPLEXITY_MATRIX } from "../data/frameworkData";

const phaseColorMap: Record<string, { accent: string; border: string; bg: string; badge: string; glow: string }> = {
  purple: { accent: "text-purple-400", border: "border-purple-500/30", bg: "bg-purple-900/15", badge: "bg-purple-500/15 text-purple-300", glow: "shadow-purple-500/10" },
  pink: { accent: "text-pink-400", border: "border-pink-500/30", bg: "bg-pink-900/15", badge: "bg-pink-500/15 text-pink-300", glow: "shadow-pink-500/10" },
  emerald: { accent: "text-emerald-400", border: "border-emerald-500/30", bg: "bg-emerald-900/15", badge: "bg-emerald-500/15 text-emerald-300", glow: "shadow-emerald-500/10" },
  yellow: { accent: "text-yellow-400", border: "border-yellow-500/30", bg: "bg-yellow-900/15", badge: "bg-yellow-500/15 text-yellow-300", glow: "shadow-yellow-500/10" },
  orange: { accent: "text-orange-400", border: "border-orange-500/30", bg: "bg-orange-900/15", badge: "bg-orange-500/15 text-orange-300", glow: "shadow-orange-500/10" },
};

const complexityColor: Record<string, string> = {
  SIMPLE: "text-emerald-400 bg-emerald-500/10 border-emerald-500/30",
  MEDIUM: "text-yellow-400 bg-yellow-500/10 border-yellow-500/30",
  COMPLEX: "text-orange-400 bg-orange-500/10 border-orange-500/30",
  ENTERPRISE: "text-red-400 bg-red-500/10 border-red-500/30",
};

export const PhasesSection: React.FC = () => {
  const [activePhase, setActivePhase] = useState(0);
  const phase = PHASES[activePhase];
  const c = phaseColorMap[phase.color];

  return (
    <section id="phases" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Section header */}
      <div className="text-center mb-14">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-4">
          <span className="text-xs font-mono text-cyan-400 font-semibold">ITERATIVE WORKFLOW STEPS</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">
          The{" "}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-emerald-400">
            SDLC Pipeline
          </span>
        </h2>
        <p className="text-gray-400 max-w-2xl mx-auto text-sm leading-relaxed">
          5 structured phases with explicit quality gates. No phase can be skipped.
          Every phase concludes with a deliverable sign-off enforced by the Project Manager.
        </p>
      </div>

      {/* Phase selector */}
      <div className="flex flex-wrap justify-center gap-2 mb-10">
        {PHASES.map((p, i) => {
          const pc = phaseColorMap[p.color];
          const isActive = i === activePhase;
          return (
            <button
              key={p.id}
              onClick={() => setActivePhase(i)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-xs font-mono font-semibold transition-all duration-200 ${
                isActive
                  ? `${pc.bg} ${pc.border} ${pc.accent} shadow-lg ${pc.glow}`
                  : "bg-white/3 border-white/8 text-gray-500 hover:text-gray-300 hover:bg-white/5"
              }`}
            >
              <span>{p.icon}</span>
              <span className="hidden sm:inline">{p.phase}</span>
              <span className="hidden md:inline">— {p.title.split("&")[0].trim()}</span>
            </button>
          );
        })}
      </div>

      {/* Phase detail */}
      <div className={`rounded-2xl border ${c.border} ${c.bg} p-6 shadow-2xl ${c.glow} mb-8`}>
        {/* Phase header */}
        <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
          <div>
            <div className={`text-xs font-mono font-bold ${c.accent} mb-1`}>{phase.phase}</div>
            <h3 className="text-xl sm:text-2xl font-black text-white mb-1">{phase.title}</h3>
            <p className="text-sm text-gray-400">{phase.subtitle}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {phase.leadAgents.map((agentId) => {
              const ag = AGENTS.find((a) => a.id === agentId);
              return ag ? (
                <span key={agentId} className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-mono border ${c.badge} border-current/20`}>
                  <span>{ag.icon}</span> {ag.trigger.replace("> ", "")}
                </span>
              ) : null;
            })}
            {phase.collaboratingAgents.map((agentId) => {
              const ag = AGENTS.find((a) => a.id === agentId);
              return ag ? (
                <span key={agentId} className="flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-mono bg-white/5 border border-white/10 text-gray-400">
                  <span>{ag.icon}</span> {ag.trigger.replace("> ", "")} <span className="opacity-60">(collab)</span>
                </span>
              ) : null;
            })}
          </div>
        </div>

        {/* Steps */}
        <div className="space-y-4 mb-6">
          {phase.steps.map((step, i) => (
            <div key={i} className="rounded-xl bg-black/20 border border-white/5 overflow-hidden">
              <div className="flex items-center gap-3 px-4 py-3 border-b border-white/5">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-mono font-bold text-gray-900 ${c.accent.replace("text-", "bg-").replace("400", "400")}`}
                  style={{ backgroundColor: "currentColor" }}>
                  <span style={{ color: "#111" }}>{i + 1}</span>
                </div>
                <span className={`text-xs font-mono font-bold ${c.accent}`}>{step.actor}</span>
                <span className="text-xs text-gray-400 ml-1 hidden sm:inline">→ {step.action}</span>
              </div>
              <div className="sm:hidden px-4 py-2 border-b border-white/5">
                <span className="text-xs text-gray-400">{step.action}</span>
              </div>

              {step.code && (
                <div className="relative">
                  <div className="flex items-center gap-2 px-4 py-2 bg-gray-900/50 border-b border-white/5">
                    <div className="w-2 h-2 rounded-full bg-red-500/50" />
                    <div className="w-2 h-2 rounded-full bg-yellow-500/50" />
                    <div className="w-2 h-2 rounded-full bg-emerald-500/50" />
                    <span className="ml-2 text-[10px] font-mono text-gray-600">{step.language}</span>
                  </div>
                  <pre className="p-4 text-xs font-mono text-gray-300 overflow-x-auto leading-relaxed max-h-64 overflow-y-auto whitespace-pre-wrap break-words">
                    {step.code}
                  </pre>
                </div>
              )}

              {step.output && (
                <div className="px-4 py-3">
                  <div className="text-xs font-mono text-gray-400 leading-relaxed">{step.output}</div>
                </div>
              )}

              {step.note && (
                <div className={`px-4 py-2 border-t border-white/5 ${c.bg}`}>
                  <div className="flex items-start gap-2">
                    <span className={`text-[10px] font-mono font-bold ${c.accent} mt-0.5`}>§§</span>
                    <span className="text-[10px] font-mono text-gray-400 leading-relaxed">{step.note}</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Deliverables + Quality Gate */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="rounded-xl bg-black/20 border border-white/5 p-4">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-base">📦</span>
              <span className="text-sm font-bold text-white">Phase Deliverables</span>
            </div>
            <ul className="space-y-1.5">
              {phase.deliverables.map((d) => (
                <li key={d} className="flex items-start gap-2">
                  <span className={`text-xs mt-0.5 ${c.accent}`}>✓</span>
                  <span className="text-xs text-gray-300">{d}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className={`rounded-xl border p-4 ${c.bg} ${c.border}`}>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-base">🚦</span>
              <span className="text-sm font-bold text-white">Quality Gate</span>
              <span className={`ml-auto text-[10px] font-mono px-2 py-0.5 rounded-full ${c.badge}`}>MANDATORY</span>
            </div>
            <p className="text-xs text-gray-300 leading-relaxed">{phase.qualityGate}</p>
          </div>
        </div>
      </div>

      {/* Phase progression arrows */}
      <div className="flex justify-center items-center gap-2 mb-14 flex-wrap">
        {PHASES.map((p, i) => (
          <React.Fragment key={p.id}>
            <button
              onClick={() => setActivePhase(i)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
                i === activePhase
                  ? `${phaseColorMap[p.color].badge} border ${phaseColorMap[p.color].border}`
                  : "text-gray-600 hover:text-gray-400"
              }`}
            >
              {p.icon} {p.phase}
            </button>
            {i < PHASES.length - 1 && (
              <span className="text-gray-700 text-xs font-mono">→</span>
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Complexity Matrix */}
      <div className="mt-4">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/20 mb-4">
            <span className="text-xs font-mono text-orange-400 font-semibold">COMPLEXITY MATRIX</span>
          </div>
          <h3 className="text-2xl font-black text-white">
            Project <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-yellow-400">Classification System</span>
          </h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {COMPLEXITY_MATRIX.map((level) => (
            <div key={level.level} className="p-5 rounded-2xl bg-gray-900/40 border border-white/8 hover:border-white/15 transition-all duration-200 group">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xl">{level.emoji}</span>
                <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded-full border ${complexityColor[level.level]}`}>
                  {level.level}
                </span>
              </div>
              <div className="text-sm font-bold text-white mb-1">{level.timeframe}</div>
              <p className="text-xs text-gray-400 mb-3 leading-relaxed">{level.description}</p>
              <div className="text-[10px] font-mono text-gray-500 mb-1">AGENTS ACTIVATED</div>
              <div className="flex flex-wrap gap-1 mb-3">
                {level.agents.map((a) => {
                  const ag = AGENTS.find((ag) => ag.id === a);
                  return ag ? (
                    <span key={a} title={ag.name} className="text-base">{ag.icon}</span>
                  ) : (
                    <span key={a} className="text-[10px] text-gray-500">{a}</span>
                  );
                })}
              </div>
              <div className="text-[10px] font-mono text-gray-500 mb-1">TECH STACK</div>
              <div className="text-[10px] text-gray-400 leading-relaxed">{level.tech}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
