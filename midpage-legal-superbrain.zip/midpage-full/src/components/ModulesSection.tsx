import React, { useState } from "react";
import { MODULES, Module } from "../data/frameworkData";

const moduleColorMap: Record<string, { accent: string; border: string; bg: string; tag: string }> = {
  purple: { accent: "text-purple-400", border: "border-purple-500/30", bg: "bg-purple-900/20", tag: "bg-purple-500/15 text-purple-300 border-purple-500/20" },
  cyan: { accent: "text-cyan-400", border: "border-cyan-500/30", bg: "bg-cyan-900/20", tag: "bg-cyan-500/15 text-cyan-300 border-cyan-500/20" },
  pink: { accent: "text-pink-400", border: "border-pink-500/30", bg: "bg-pink-900/20", tag: "bg-pink-500/15 text-pink-300 border-pink-500/20" },
  emerald: { accent: "text-emerald-400", border: "border-emerald-500/30", bg: "bg-emerald-900/20", tag: "bg-emerald-500/15 text-emerald-300 border-emerald-500/20" },
  yellow: { accent: "text-yellow-400", border: "border-yellow-500/30", bg: "bg-yellow-900/20", tag: "bg-yellow-500/15 text-yellow-300 border-yellow-500/20" },
  orange: { accent: "text-orange-400", border: "border-orange-500/30", bg: "bg-orange-900/20", tag: "bg-orange-500/15 text-orange-300 border-orange-500/20" },
  blue: { accent: "text-blue-400", border: "border-blue-500/30", bg: "bg-blue-900/20", tag: "bg-blue-500/15 text-blue-300 border-blue-500/20" },
};

const ModuleCard: React.FC<{ module: Module; isSelected: boolean; onClick: () => void }> = ({ module, isSelected, onClick }) => {
  const c = moduleColorMap[module.color] || moduleColorMap["purple"];
  return (
    <button
      onClick={onClick}
      className={`w-full text-left p-4 rounded-2xl border transition-all duration-200 group ${
        isSelected ? `${c.bg} ${c.border} shadow-lg` : "bg-white/3 border-white/8 hover:bg-white/5 hover:border-white/12"
      }`}
    >
      <div className="flex items-center gap-3">
        <span className={`text-xl w-9 h-9 flex items-center justify-center rounded-xl border ${isSelected ? `${c.bg} ${c.border}` : "bg-white/5 border-white/10"}`}>
          {module.icon}
        </span>
        <div className="flex-1 min-w-0">
          <div className={`text-xs font-bold ${isSelected ? c.accent : "text-gray-400"} font-mono mb-0.5`}>
            MODULE {module.id.toString().padStart(2, "0")}
          </div>
          <div className="text-sm font-semibold text-white truncate">{module.name}</div>
        </div>
        <span className={`text-xs font-mono transition-transform ${isSelected ? c.accent + " rotate-90" : "text-gray-600"}`}>▶</span>
      </div>
    </button>
  );
};

export const ModulesSection: React.FC = () => {
  const [selected, setSelected] = useState(0);
  const module = MODULES[selected];
  const c = moduleColorMap[module.color] || moduleColorMap["purple"];

  return (
    <section id="modules" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center mb-14">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 mb-4">
          <span className="text-xs font-mono text-emerald-400 font-semibold">MODULAR SYSTEM COMPONENTS</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">
          7 Core{" "}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">
            Framework Modules
          </span>
        </h2>
        <p className="text-gray-400 max-w-2xl mx-auto text-sm leading-relaxed">
          Each module is independently configurable and scales from simple projects to enterprise
          deployments. Select a module to explore its capabilities and technology stack.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Module list */}
        <div className="space-y-2">
          {MODULES.map((m, i) => (
            <ModuleCard key={m.id} module={m} isSelected={selected === i} onClick={() => setSelected(i)} />
          ))}
        </div>

        {/* Module detail */}
        <div className="lg:col-span-2 space-y-4">
          <div className={`p-6 rounded-2xl border ${c.bg} ${c.border} shadow-xl`}>
            <div className="flex items-start gap-4 mb-5">
              <div className={`text-4xl w-16 h-16 flex items-center justify-center rounded-2xl border ${c.bg} ${c.border}`}>
                {module.icon}
              </div>
              <div>
                <div className={`text-[10px] font-mono font-bold ${c.accent} mb-1`}>MODULE {module.id.toString().padStart(2, "0")}</div>
                <h3 className="text-xl font-black text-white">{module.name}</h3>
                <p className="text-sm text-gray-300 mt-1 leading-relaxed">{module.description}</p>
              </div>
            </div>

            {/* Features */}
            <div className="mb-5">
              <div className="text-xs font-mono text-gray-500 mb-3 font-semibold">KEY CAPABILITIES</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {module.features.map((f) => (
                  <div key={f} className="flex items-start gap-2 p-3 rounded-xl bg-black/20 border border-white/5">
                    <span className={`text-xs ${c.accent} mt-0.5 font-bold flex-shrink-0`}>✓</span>
                    <span className="text-xs text-gray-300 leading-relaxed">{f}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Tech stack */}
            <div>
              <div className="text-xs font-mono text-gray-500 mb-3 font-semibold">TECHNOLOGY STACK</div>
              <div className="flex flex-wrap gap-2">
                {module.techStack.map((t) => (
                  <span key={t} className={`text-xs font-mono px-3 py-1.5 rounded-lg border ${c.tag}`}>
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Best Practice Mandate for this module */}
          <div className="p-5 rounded-2xl bg-gray-900/50 border border-white/8">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-yellow-400 text-base">§§</span>
              <span className="text-xs font-mono font-bold text-yellow-400">BEST_PRACTICE_MANDATES — MODULE {module.id}</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { label: "Code Coverage", value: "≥85%", icon: "🧪", color: "text-emerald-400" },
                { label: "Lighthouse Score", value: "≥95", icon: "⚡", color: "text-yellow-400" },
                { label: "Security CVEs", value: "0 Critical", icon: "🔒", color: "text-red-400" },
              ].map((m) => (
                <div key={m.label} className="text-center p-3 rounded-xl bg-black/20 border border-white/5">
                  <div className="text-2xl mb-1">{m.icon}</div>
                  <div className={`text-lg font-black font-mono ${m.color}`}>{m.value}</div>
                  <div className="text-[10px] text-gray-500">{m.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
