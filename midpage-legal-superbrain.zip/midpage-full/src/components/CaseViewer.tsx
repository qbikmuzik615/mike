import { useState } from 'react';
import { ArrowLeft, Star, BookmarkPlus, Share2, Printer, ChevronRight, ChevronDown, CheckCircle, XCircle, AlertTriangle, Clock, Link2, FileText, List, BookOpen, TrendingUp } from 'lucide-react';
import { CASES } from '../data/cases';

interface CaseViewerProps {
  caseId: string;
  onBack: () => void;
  onSelectCase: (id: string) => void;
}

const STATUS_CONFIG = {
  good: { icon: CheckCircle, label: 'Good Law', color: '#166534', bg: '#dcfce7', border: '#86efac' },
  bad: { icon: XCircle, label: 'Overruled', color: '#991b1b', bg: '#fee2e2', border: '#fca5a5' },
  caution: { icon: AlertTriangle, label: 'Caution', color: '#854d0e', bg: '#fef9c3', border: '#fde047' },
  neutral: { icon: Clock, label: 'Neutral', color: '#475569', bg: '#f1f5f9', border: '#cbd5e1' },
};

const TREATMENT_CONFIG = {
  follows: { label: 'Follows', color: '#166534', bg: '#dcfce7' },
  distinguishes: { label: 'Distinguishes', color: '#854d0e', bg: '#fef9c3' },
  criticizes: { label: 'Criticizes', color: '#9a3412', bg: '#fff7ed' },
  overrules: { label: 'Overrules', color: '#991b1b', bg: '#fee2e2' },
  explains: { label: 'Explains', color: '#1e40af', bg: '#dbeafe' },
};

type Tab = 'opinion' | 'headnotes' | 'citing' | 'analysis';

export default function CaseViewer({ caseId, onBack, onSelectCase }: CaseViewerProps) {
  const c = CASES.find(x => x.id === caseId);
  const [tab, setTab] = useState<Tab>('opinion');
  const [saved, setSaved] = useState(false);
  const [expandedSection, setExpandedSection] = useState<string | null>('s1');
  const [copiedCitation, setCopiedCitation] = useState(false);

  if (!c) return (
    <div className="flex-1 flex items-center justify-center" style={{ background: '#f8f7f4' }}>
      <p className="text-sm" style={{ color: '#6b5a4a' }}>Case not found</p>
    </div>
  );

  const StatusIcon = STATUS_CONFIG[c.status].icon;
  const statusCfg = STATUS_CONFIG[c.status];

  const copyCitation = () => {
    navigator.clipboard.writeText(c.citation).then(() => {
      setCopiedCitation(true);
      setTimeout(() => setCopiedCitation(false), 2000);
    });
  };

  const tabs: { id: Tab; label: string; icon: typeof FileText }[] = [
    { id: 'opinion', label: 'Full Opinion', icon: FileText },
    { id: 'headnotes', label: 'Headnotes & Holdings', icon: List },
    { id: 'citing', label: `Citing Cases (${c.citedBy.length})`, icon: TrendingUp },
    { id: 'analysis', label: 'Analysis', icon: BookOpen },
  ];

  return (
    <div className="flex h-full" style={{ background: '#f8f7f4' }}>
      {/* Left panel: case meta + TOC */}
      <aside className="w-64 flex-shrink-0 border-r bg-white overflow-auto sidebar-scroll" style={{ borderColor: '#e5e0d8' }}>
        {/* Back */}
        <div className="p-3 border-b" style={{ borderColor: '#e5e0d8' }}>
          <button
            onClick={onBack}
            className="flex items-center gap-1.5 text-xs font-medium hover:text-gray-900 transition-colors"
            style={{ color: '#6b5a4a' }}
          >
            <ArrowLeft size={13} /> Back to results
          </button>
        </div>

        {/* Case header */}
        <div className="p-4 border-b" style={{ borderColor: '#e5e0d8' }}>
          {/* Status */}
          <span
            className="inline-flex items-center gap-1.5 px-2 py-1 rounded text-xs font-medium border mb-3"
            style={{ color: statusCfg.color, background: statusCfg.bg, borderColor: statusCfg.border }}
          >
            <StatusIcon size={11} />
            {statusCfg.label}
          </span>

          {c.status === 'bad' && (
            <div className="mb-3 p-2.5 rounded-lg border text-xs" style={{ background: '#fff5f5', borderColor: '#fca5a5', color: '#991b1b' }}>
              ⚠️ This case has been <strong>overruled</strong>. Check citing cases before relying on this authority.
            </div>
          )}

          <h2 className="font-serif text-base leading-tight mb-1" style={{ color: '#1a1a2e', fontFamily: 'Crimson Pro, serif', fontWeight: 600 }}>
            {c.shortName}
          </h2>
          <p className="text-xs mb-1" style={{ color: '#6b5a4a' }}>{c.fullName}</p>
          <p className="text-xs font-medium mb-3" style={{ color: '#8b6f4e' }}>{c.citation}</p>

          <div className="space-y-1.5 text-xs" style={{ color: '#5a5a5a' }}>
            <div className="flex gap-2">
              <span className="font-medium w-16 flex-shrink-0" style={{ color: '#1a1a2e' }}>Court</span>
              <span>{c.court}</span>
            </div>
            <div className="flex gap-2">
              <span className="font-medium w-16 flex-shrink-0" style={{ color: '#1a1a2e' }}>Date</span>
              <span>{c.date}</span>
            </div>
            <div className="flex gap-2">
              <span className="font-medium w-16 flex-shrink-0" style={{ color: '#1a1a2e' }}>Docket</span>
              <span>{c.docketNumber}</span>
            </div>
          </div>
        </div>

        {/* Practice areas */}
        <div className="p-4 border-b" style={{ borderColor: '#e5e0d8' }}>
          <p className="text-xs font-medium mb-2" style={{ color: '#1a1a2e' }}>Practice Areas</p>
          <div className="flex flex-wrap gap-1">
            {c.practiceAreas.map(a => (
              <span key={a} className="px-2 py-0.5 rounded-full text-xs" style={{ background: '#f5f2ed', color: '#6b5a4a' }}>
                {a}
              </span>
            ))}
          </div>
        </div>

        {/* Judges */}
        <div className="p-4 border-b" style={{ borderColor: '#e5e0d8' }}>
          <p className="text-xs font-medium mb-2" style={{ color: '#1a1a2e' }}>Judicial Panel</p>
          <div className="space-y-1">
            {c.judges.slice(0, 4).map((j, i) => (
              <div key={j} className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full flex items-center justify-center text-white text-xs flex-shrink-0"
                  style={{ background: i === 0 ? '#1a1a2e' : '#8b6f4e', fontSize: '9px' }}>
                  {j.split(' ').pop()![0]}
                </div>
                <span className="text-xs" style={{ color: '#5a5a5a' }}>{j}</span>
              </div>
            ))}
            {c.judges.length > 4 && (
              <p className="text-xs" style={{ color: '#8b8b8b' }}>+{c.judges.length - 4} more</p>
            )}
          </div>
        </div>

        {/* TOC */}
        {tab === 'opinion' && (
          <div className="p-4">
            <p className="text-xs font-medium mb-2" style={{ color: '#1a1a2e' }}>Contents</p>
            <nav className="space-y-0.5">
              {c.fullText.map(s => (
                <button
                  key={s.id}
                  onClick={() => {
                    setExpandedSection(s.id);
                    document.getElementById(`section-${s.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }}
                  className={`w-full text-left px-2 py-1.5 rounded text-xs transition-all ${
                    expandedSection === s.id ? 'font-medium' : ''
                  }`}
                  style={expandedSection === s.id ? { background: '#f5f2ed', color: '#5a3e2b' } : { color: '#6b5a4a' }}
                >
                  {s.heading || `Section ${s.id}`}
                </button>
              ))}
            </nav>
          </div>
        )}
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-auto">
        {/* Action bar */}
        <div className="sticky top-0 bg-white border-b px-6 py-2 flex items-center gap-2 z-10" style={{ borderColor: '#e5e0d8' }}>
          <div className="flex-1 flex gap-1 overflow-auto">
            {tabs.map(t => {
              const Icon = t.icon;
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all whitespace-nowrap ${
                    tab === t.id
                      ? 'text-amber-800'
                      : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                  }`}
                  style={tab === t.id ? { background: '#fef9f0' } : {}}
                >
                  <Icon size={12} />
                  {t.label}
                </button>
              );
            })}
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            <button
              onClick={copyCitation}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium border transition-all hover:bg-gray-50"
              style={{ borderColor: '#d4c9b8', color: '#5a5a5a' }}
            >
              <Link2 size={11} />
              {copiedCitation ? 'Copied!' : 'Cite'}
            </button>
            <button
              onClick={() => setSaved(!saved)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium border transition-all hover:bg-gray-50 ${saved ? 'text-amber-700' : 'text-gray-500'}`}
              style={{ borderColor: '#d4c9b8' }}
            >
              {saved ? <Star size={11} fill="currentColor" /> : <BookmarkPlus size={11} />}
              {saved ? 'Saved' : 'Save'}
            </button>
            <button
              className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium border transition-all hover:bg-gray-50"
              style={{ borderColor: '#d4c9b8', color: '#5a5a5a' }}
            >
              <Share2 size={11} /> Share
            </button>
            <button
              className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium border transition-all hover:bg-gray-50"
              style={{ borderColor: '#d4c9b8', color: '#5a5a5a' }}
            >
              <Printer size={11} /> Print
            </button>
          </div>
        </div>

        {/* Tab content */}
        <div className="max-w-3xl mx-auto px-8 py-6">

          {/* Opinion tab */}
          {tab === 'opinion' && (
            <div>
              <div className="mb-6">
                <h1 className="font-serif text-2xl mb-1 leading-tight" style={{ color: '#1a1a2e', fontFamily: 'Crimson Pro, serif' }}>
                  {c.fullName}
                </h1>
                <p className="text-sm mb-1" style={{ color: '#8b6f4e' }}>{c.citation}</p>
                <p className="text-xs" style={{ color: '#6b5a4a' }}>{c.court} · Decided {c.date}</p>
              </div>

              {/* Key excerpt */}
              <div className="mb-6 p-4 rounded-xl border" style={{ background: '#fefcf8', borderColor: '#d4c9b8' }}>
                <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: '#8b6f4e' }}>Key Excerpt</p>
                <p className="font-serif text-base leading-relaxed italic selectable-text" style={{ color: '#2d2d2d', fontFamily: 'Crimson Pro, Georgia, serif' }}>
                  "{c.excerpt}"
                </p>
              </div>

              {/* Full text sections */}
              <div className="space-y-1">
                {c.fullText.map(s => (
                  <div key={s.id} id={`section-${s.id}`} className="border rounded-xl overflow-hidden" style={{ borderColor: '#e5e0d8' }}>
                    <button
                      onClick={() => setExpandedSection(expandedSection === s.id ? null : s.id)}
                      className="w-full flex items-center justify-between p-4 text-left hover:bg-gray-50 transition-colors"
                      style={{ background: expandedSection === s.id ? '#fafaf8' : 'white' }}
                    >
                      <h3 className="font-serif font-semibold text-sm" style={{ color: '#1a1a2e', fontFamily: 'Crimson Pro, serif' }}>
                        {s.heading || 'Text'}
                      </h3>
                      {expandedSection === s.id
                        ? <ChevronDown size={14} style={{ color: '#8b8b8b' }} />
                        : <ChevronRight size={14} style={{ color: '#8b8b8b' }} />
                      }
                    </button>
                    {expandedSection === s.id && (
                      <div className="px-5 pb-5 border-t" style={{ borderColor: '#f0ede8' }}>
                        <div className="case-prose pt-4">
                          {s.content.split('\n\n').map((para, i) => (
                            <p key={i} className="selectable-text" style={{ fontFamily: 'Crimson Pro, Georgia, serif', fontSize: '1.05rem', lineHeight: 1.8, color: '#2d2d2d', marginBottom: '1rem' }}>
                              {para}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Headnotes tab */}
          {tab === 'headnotes' && (
            <div>
              <h2 className="font-serif text-xl mb-5" style={{ color: '#1a1a2e', fontFamily: 'Crimson Pro, serif' }}>Holdings</h2>
              <div className="space-y-3 mb-8">
                {c.holdings.map((h, i) => (
                  <div key={i} className="flex gap-3 p-4 rounded-xl border" style={{ background: '#fefcf8', borderColor: '#d4c9b8' }}>
                    <div className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0 mt-0.5"
                      style={{ background: '#1a1a2e' }}>
                      {i + 1}
                    </div>
                    <p className="text-sm leading-relaxed" style={{ color: '#2d2d2d', fontFamily: 'Crimson Pro, Georgia, serif', fontSize: '1rem' }}>
                      {h}
                    </p>
                  </div>
                ))}
              </div>

              <h2 className="font-serif text-xl mb-5" style={{ color: '#1a1a2e', fontFamily: 'Crimson Pro, serif' }}>Headnotes</h2>
              <div className="space-y-3">
                {c.headnotes.map((h, i) => (
                  <div key={i} className="flex gap-3 p-4 rounded-xl border" style={{ background: 'white', borderColor: '#e5e0d8' }}>
                    <div className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5"
                      style={{ background: '#f5f2ed', color: '#8b6f4e' }}>
                      HN{i + 1}
                    </div>
                    <p className="text-sm leading-relaxed" style={{ color: '#4a4a4a' }}>{h}</p>
                  </div>
                ))}
              </div>

              {c.cites.length > 0 && (
                <div className="mt-8">
                  <h2 className="font-serif text-xl mb-4" style={{ color: '#1a1a2e', fontFamily: 'Crimson Pro, serif' }}>Cases Cited</h2>
                  <div className="flex flex-wrap gap-2">
                    {c.cites.map(cite => (
                      <span key={cite} className="citation-chip">{cite}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Citing cases tab */}
          {tab === 'citing' && (
            <div>
              <h2 className="font-serif text-xl mb-5" style={{ color: '#1a1a2e', fontFamily: 'Crimson Pro, serif' }}>
                Cases Citing {c.shortName}
              </h2>
              {c.citedBy.length === 0 ? (
                <div className="text-center py-12">
                  <TrendingUp size={28} className="mx-auto mb-3" style={{ color: '#c8b89a' }} />
                  <p className="text-sm" style={{ color: '#6b5a4a' }}>No citing cases in our database</p>
                  <p className="text-xs mt-1" style={{ color: '#8b8b8b' }}>This may be a very recent decision</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {c.citedBy.map(citing => {
                    const treatCfg = TREATMENT_CONFIG[citing.treatment];
                    return (
                      <div
                        key={citing.id}
                        className="border rounded-xl p-5 hover:shadow-md transition-all cursor-pointer"
                        style={{ background: 'white', borderColor: '#e5e0d8' }}
                        onClick={() => onSelectCase(citing.id)}
                      >
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <div>
                            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold mb-2"
                              style={{ background: treatCfg.bg, color: treatCfg.color }}>
                              {treatCfg.label}
                            </span>
                            <h3 className="font-medium text-sm" style={{ color: '#1a1a2e' }}>{citing.shortName}</h3>
                            <p className="text-xs mt-0.5" style={{ color: '#8b6f4e' }}>
                              {citing.citation} · {citing.court}
                            </p>
                          </div>
                          <ChevronRight size={16} style={{ color: '#8b8b8b' }} className="flex-shrink-0 mt-1" />
                        </div>
                        <blockquote className="border-l-2 pl-3 text-sm italic leading-relaxed"
                          style={{ borderColor: '#c8b89a', color: '#4a4a4a', fontFamily: 'Crimson Pro, Georgia, serif' }}>
                          "{citing.snippet}"
                        </blockquote>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Analysis tab */}
          {tab === 'analysis' && (
            <div>
              <h2 className="font-serif text-xl mb-5" style={{ color: '#1a1a2e', fontFamily: 'Crimson Pro, serif' }}>AI Case Analysis</h2>

              <div className="space-y-4">
                <div className="p-5 rounded-xl border" style={{ background: 'white', borderColor: '#e5e0d8' }}>
                  <h3 className="text-sm font-semibold mb-3" style={{ color: '#1a1a2e' }}>📋 Summary</h3>
                  <p className="text-sm leading-relaxed" style={{ color: '#4a4a4a' }}>
                    <em>{c.shortName}</em>, {c.citation}, is a landmark {c.court} decision addressing {c.practiceAreas.join(', ')}.
                    Decided on {c.date}, this case established foundational principles that continue to shape legal practice.
                  </p>
                </div>

                <div className="p-5 rounded-xl border" style={{ background: 'white', borderColor: '#e5e0d8' }}>
                  <h3 className="text-sm font-semibold mb-3" style={{ color: '#1a1a2e' }}>⚖️ Legal Significance</h3>
                  <ul className="space-y-2">
                    {c.holdings.map((h, i) => (
                      <li key={i} className="flex gap-2 text-sm" style={{ color: '#4a4a4a' }}>
                        <span className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: '#8b6f4e' }} />
                        {h}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-5 rounded-xl border" style={{ background: 'white', borderColor: '#e5e0d8' }}>
                  <h3 className="text-sm font-semibold mb-3" style={{ color: '#1a1a2e' }}>🔍 Current Status</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium border"
                      style={{ color: statusCfg.color, background: statusCfg.bg, borderColor: statusCfg.border }}>
                      <StatusIcon size={11} />
                      {statusCfg.label}
                    </span>
                    {c.citedBy.length > 0 && (
                      <span className="text-xs" style={{ color: '#6b5a4a' }}>
                        · Cited by {c.citedBy.length} case{c.citedBy.length !== 1 ? 's' : ''} in our database
                      </span>
                    )}
                  </div>
                  {c.status === 'bad' ? (
                    <p className="text-sm" style={{ color: '#991b1b' }}>
                      ⚠️ This case has been overruled and should not be relied upon as controlling authority. 
                      Review citing cases to understand current state of the law.
                    </p>
                  ) : (
                    <p className="text-sm" style={{ color: '#4a4a4a' }}>
                      This case remains good law and can be cited as authority in the relevant jurisdictions.
                    </p>
                  )}
                </div>

                <div className="p-5 rounded-xl border" style={{ background: 'white', borderColor: '#e5e0d8' }}>
                  <h3 className="text-sm font-semibold mb-3" style={{ color: '#1a1a2e' }}>💡 Practice Tips</h3>
                  <ul className="space-y-2 text-sm" style={{ color: '#4a4a4a' }}>
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">→</span>
                      Always verify the current status of this case before citing in court filings.
                    </li>
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">→</span>
                      Review the {c.citedBy.length} citing cases for subsequent development of the law.
                    </li>
                    <li className="flex gap-2">
                      <span className="flex-shrink-0">→</span>
                      Consider jurisdiction-specific treatment when applying this precedent.
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
