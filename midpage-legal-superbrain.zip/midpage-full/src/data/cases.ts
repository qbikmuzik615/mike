import { Case } from '../types';

export const CASES: Case[] = [
  {
    id: 'twombly',
    citation: '550 U.S. 544 (2007)',
    shortName: 'Bell Atl. Corp. v. Twombly',
    fullName: 'Bell Atlantic Corporation v. William Twombly',
    court: 'Supreme Court of the United States',
    date: 'May 21, 2007',
    year: 2007,
    jurisdiction: 'Federal',
    judges: ['Justice Souter', 'Chief Justice Roberts', 'Justice Scalia', 'Justice Kennedy', 'Justice Thomas', 'Justice Breyer', 'Justice Alito'],
    docketNumber: '05-1126',
    status: 'good',
    statusLabel: 'Good Law',
    practiceAreas: ['Civil Procedure', 'Antitrust', 'Pleading Standards'],
    headnotes: [
      'Stating a claim under § 1 of the Sherman Act requires a complaint with enough factual matter to suggest that an agreement was made.',
      'An allegation of parallel conduct and a bare assertion of conspiracy will not suffice under Rule 8(a)(2).',
      'The "no set of facts" language of Conley v. Gibson has earned its retirement.',
    ],
    holdings: [
      'To survive a motion to dismiss, a complaint must contain sufficient factual matter, accepted as true, to "state a claim to relief that is plausible on its face."',
      'A claim has facial plausibility when the plaintiff pleads factual content that allows the court to draw the reasonable inference that the defendant is liable for the misconduct alleged.',
    ],
    excerpt: 'While a complaint attacked by a Rule 12(b)(6) motion to dismiss does not need detailed factual allegations, a plaintiff\'s obligation to provide the "grounds" of his "entitlement to relief" requires more than labels and conclusions, and a formulaic recitation of the elements of a cause of action will not do.',
    fullText: [
      {
        id: 's1',
        heading: 'OPINION OF THE COURT',
        content: 'Justice Souter delivered the opinion of the Court.\n\nRespondents William Twombly and Lawrence Marcus (hereinafter plaintiffs) represent a putative class consisting of all "subscribers of local telephone and/or high speed internet services... from February 8, 1996 to present." In this action against petitioners, a group of ILECs, plaintiffs seek treble damages and declaratory and injunctive relief for claimed violations of § 1 of the Sherman Act, ch. 647, 26 Stat. 209, as amended, 15 U.S.C. § 1, which prohibits "[e]very contract, combination in the form of trust or otherwise, or conspiracy, in restraint of trade or commerce among the several States, or with foreign nations."',
      },
      {
        id: 's2',
        heading: 'I',
        content: 'The complaint alleges that the ILECs conspired to restrain trade in two ways, each supposedly inflating charges for local telephone and high-speed internet services. Plaintiffs say, first, that the ILECs "engaged in parallel conduct" in their respective service areas to inhibit the growth of upstart CLECs. Plaintiffs allege that the ILECs\' actions included making unfair agreements with the CLECs for access to ILEC networks, providing inferior connections to the networks, overcharging, and billing in ways designed to sabotage the CLECs\' relations with their own customers.',
      },
      {
        id: 's3',
        heading: 'II',
        content: 'Federal Rule of Civil Procedure 8(a)(2) requires only "a short and plain statement of the claim showing that the pleader is entitled to relief," in order to "give the defendant fair notice of what the... claim is and the grounds upon which it rests." While a complaint attacked by a Rule 12(b)(6) motion to dismiss does not need detailed factual allegations, a plaintiff\'s obligation to provide the "grounds" of his "entitlement to relief" requires more than labels and conclusions, and a formulaic recitation of the elements of a cause of action will not do.',
      },
      {
        id: 's4',
        heading: 'III',
        content: 'We alluded to the practical significance of the Rule 8 entitlement requirement in Dura Pharmaceuticals, Inc. v. Broudo, 544 U.S. 336 (2005), when we explained that something beyond the mere possibility of loss causation must be alleged, lest a plaintiff with "a largely groundless claim" be allowed to "take up the time of a number of other people, with the right to do so representing an in terrorem increment of the settlement value." So, when the allegations in a complaint, however true, could not raise a claim of entitlement to relief, "this basic deficiency should... be exposed at the point of minimum expenditure of time and money by the parties and the court."',
      },
      {
        id: 's5',
        heading: 'CONCLUSION',
        content: 'The judgment of the Court of Appeals for the Second Circuit is reversed, and the cause is remanded for further proceedings consistent with this opinion. Because we find dismissal of the complaint appropriate under Rule 8 of the Federal Rules of Civil Procedure, we do not reach the ILECs\' alternative argument for dismissal based upon the District Court\'s earlier ruling that the ILECs are immune from antitrust liability for the alleged conduct. It is so ordered.',
      },
    ],
    citedBy: [
      {
        id: 'iqbal',
        citation: '556 U.S. 662 (2009)',
        shortName: 'Ashcroft v. Iqbal',
        court: 'Supreme Court of the United States',
        year: 2009,
        treatment: 'follows',
        snippet: 'Twombly expounded the pleading standard for "all civil actions" in federal court, and we now hold that the pleading standard Twombly announced applies to all civil actions...',
      },
      {
        id: 'matrixx',
        citation: '563 U.S. 27 (2011)',
        shortName: 'Matrixx Initiatives, Inc. v. Siracusano',
        court: 'Supreme Court of the United States',
        year: 2011,
        treatment: 'follows',
        snippet: 'Under our decision in Twombly, a complaint must contain sufficient factual matter, accepted as true, to state a claim...',
      },
      {
        id: 'swanson',
        citation: '614 F.3d 400 (7th Cir. 2010)',
        shortName: 'Swanson v. Citibank, N.A.',
        court: 'U.S. Court of Appeals, 7th Circuit',
        year: 2010,
        treatment: 'follows',
        snippet: 'At the same time, we must keep Twombly\'s instruction in mind that the court\'s task is not to evaluate whether the pleader has offered enough to prove the claim...',
      },
    ],
    cites: ['355 U.S. 41 (1957)', '544 U.S. 336 (2005)', '509 U.S. 209 (1993)'],
    snippet: 'A complaint must contain sufficient factual matter to state a claim to relief that is plausible on its face, moving beyond mere labels and conclusions.',
    relevanceScore: 98,
  },
  {
    id: 'iqbal',
    citation: '556 U.S. 662 (2009)',
    shortName: 'Ashcroft v. Iqbal',
    fullName: 'Javaid Iqbal v. John Ashcroft',
    court: 'Supreme Court of the United States',
    date: 'May 18, 2009',
    year: 2009,
    jurisdiction: 'Federal',
    judges: ['Justice Kennedy', 'Chief Justice Roberts', 'Justice Scalia', 'Justice Thomas', 'Justice Alito'],
    docketNumber: '07-1015',
    status: 'good',
    statusLabel: 'Good Law',
    practiceAreas: ['Civil Procedure', 'Constitutional Law', 'Pleading Standards'],
    headnotes: [
      'Two working principles underlie the Twombly decision for pleading sufficiency.',
      'Determining whether a complaint states a plausible claim is context-specific, requiring the reviewing court to draw on its judicial experience and common sense.',
      'Where the well-pleaded facts do not permit the court to infer more than the mere possibility of misconduct, the complaint has alleged—but has not "shown"—that the pleader is entitled to relief.',
    ],
    holdings: [
      'Plausibility standard set out in Twombly applies in all civil actions in federal court.',
      'A pleading that offers labels and conclusions or a formulaic recitation of the elements of a cause of action will not do.',
      'Determining whether a complaint states a plausible claim for relief is a context-specific task that requires the reviewing court to draw on its judicial experience and common sense.',
    ],
    excerpt: 'Two working principles underlie our decision in Twombly. First, the tenet that a court must accept as true all of the allegations contained in a complaint is inapplicable to legal conclusions. Threadbare recitals of the elements of a cause of action, supported by mere conclusory statements, do not suffice.',
    fullText: [
      {
        id: 's1',
        heading: 'OPINION OF THE COURT',
        content: 'Justice Kennedy delivered the opinion of the Court.\n\nRespondent Javaid Iqbal is a citizen of Pakistan and a Muslim. In the wake of the September 11, 2001, terrorist attacks he was arrested in the United States on criminal charges and detained by federal officials. Respondent claims he was deprived of various constitutional protections while in federal custody.',
      },
      {
        id: 's2',
        heading: 'I',
        content: 'In the District Court, petitioners moved to dismiss the complaint for failure to state sufficient allegations to show their own involvement in clearly established unconstitutional conduct. The District Court denied the motion to dismiss, concluding that respondent\'s allegations were sufficient to state a claim despite petitioners\' official status at the times in question.',
      },
      {
        id: 's3',
        heading: 'II',
        content: 'We turn to respondent\'s complaint. Under Federal Rule of Civil Procedure 8(a)(2), a pleading must contain a "short and plain statement of the claim showing that the pleader is entitled to relief." As the Court held in Twombly, the pleading standard Rule 8 announces does not require "detailed factual allegations," but it demands more than an unadorned, the-defendant-unlawfully-harmed-me accusation. A pleading that offers "labels and conclusions" or "a formulaic recitation of the elements of a cause of action will not do." Nor does a complaint suffice if it tenders "naked assertion[s]" devoid of "further factual enhancement."',
      },
      {
        id: 's4',
        heading: 'III',
        content: 'Two working principles underlie our decision in Twombly. First, the tenet that a court must accept as true all of the allegations contained in a complaint is inapplicable to legal conclusions. Threadbare recitals of the elements of a cause of action, supported by mere conclusory statements, do not suffice. Rule 8 marks a notable and generous departure from the hyper-technical, code-pleading regime of a prior era, but it does not unlock the doors of discovery for a plaintiff armed with nothing more than conclusions. Second, only a complaint that states a plausible claim for relief survives a motion to dismiss.',
      },
    ],
    citedBy: [
      {
        id: 'matrixx',
        citation: '563 U.S. 27 (2011)',
        shortName: 'Matrixx Initiatives, Inc. v. Siracusano',
        court: 'Supreme Court of the United States',
        year: 2011,
        treatment: 'follows',
        snippet: 'Under Iqbal and Twombly, a complaint must contain sufficient factual matter to state a plausible claim...',
      },
    ],
    cites: ['550 U.S. 544 (2007)', '355 U.S. 41 (1957)'],
    snippet: 'Establishes that the Twombly plausibility pleading standard applies to all civil actions in federal court, requiring plausible—not merely conceivable—claims.',
    relevanceScore: 96,
  },
  {
    id: 'miranda',
    citation: '384 U.S. 436 (1966)',
    shortName: 'Miranda v. Arizona',
    fullName: 'Ernesto Miranda v. State of Arizona',
    court: 'Supreme Court of the United States',
    date: 'June 13, 1966',
    year: 1966,
    jurisdiction: 'Federal',
    judges: ['Chief Justice Warren', 'Justice Black', 'Justice Douglas', 'Justice Brennan', 'Justice Fortas'],
    docketNumber: '759',
    status: 'good',
    statusLabel: 'Good Law',
    practiceAreas: ['Criminal Law', 'Constitutional Law', 'Fifth Amendment', 'Sixth Amendment'],
    headnotes: [
      'Prior to any custodial interrogation, persons must be warned that they have the right to remain silent.',
      'The defendant may waive effectuation of these rights, provided the waiver is made voluntarily, knowingly and intelligently.',
      'The defendant\'s right to have counsel present during interrogation is an absolute right.',
    ],
    holdings: [
      'Prosecution may not use statements stemming from custodial interrogation of the defendant unless it demonstrates use of procedural safeguards effective to secure the privilege against self-incrimination.',
      'Prior to questioning, the person must be warned they have the right to remain silent, that any statement made may be used against them, and that they have the right to retained or appointed counsel.',
    ],
    excerpt: 'The prosecution may not use statements, whether exculpatory or inculpatory, stemming from custodial interrogation of the defendant unless it demonstrates the use of procedural safeguards effective to secure the privilege against self-incrimination.',
    fullText: [
      {
        id: 's1',
        heading: 'OPINION OF THE COURT',
        content: 'Chief Justice Warren delivered the opinion of the Court.\n\nThe cases before us raise questions which go to the roots of our concepts of American criminal jurisprudence: the restraints society must observe consistent with the Federal Constitution in prosecuting individuals for crime. More specifically, we concern ourselves with the admissibility of statements obtained from an individual who is subjected to custodial police interrogation and the necessity for procedures which assure that the individual is accorded his privilege under the Fifth Amendment to the Constitution not to be compelled to incriminate himself.',
      },
      {
        id: 's2',
        heading: 'I',
        content: 'We dealt with certain phases of this problem recently in Escobedo v. State of Illinois, 378 U.S. 478 (1964). There, as in the four cases before us, law enforcement officials took the defendant into custody and interrogated him in a police station for the purpose of obtaining a confession. The police did not effectively advise him of his right to remain silent or of his right to consult with his attorney. Rather, they confronted him with an alleged accomplice who accused him of having perpetrated a murder. When the defendant denied the accusation and said "I didn\'t shoot Manuel, you did it," they handcuffed him and took him to an interrogation room.',
      },
      {
        id: 's3',
        heading: 'II',
        content: 'At the outset, if a person in custody is to be subjected to interrogation, he must first be informed in clear and unequivocal terms that he has the right to remain silent. For those unaware of the privilege, the warning is needed simply to make them aware of it—the threshold requirement for an intelligent decision as to its exercise. More important, such a warning is an absolute prerequisite in overcoming the inherent pressures of the interrogation atmosphere.',
      },
    ],
    citedBy: [
      {
        id: 'berghuis',
        citation: '560 U.S. 370 (2010)',
        shortName: 'Berghuis v. Thompkins',
        court: 'Supreme Court of the United States',
        year: 2010,
        treatment: 'follows',
        snippet: 'Miranda v. Arizona established that an accused person... must be warned of the right to remain silent.',
      },
    ],
    cites: ['378 U.S. 478 (1964)', '377 U.S. 201 (1964)'],
    snippet: 'Established the constitutional requirement that suspects must be informed of their rights before custodial interrogation—the "Miranda warnings."',
    relevanceScore: 91,
  },
  {
    id: 'brown',
    citation: '347 U.S. 483 (1954)',
    shortName: 'Brown v. Board of Education',
    fullName: 'Oliver Brown, et al. v. Board of Education of Topeka, et al.',
    court: 'Supreme Court of the United States',
    date: 'May 17, 1954',
    year: 1954,
    jurisdiction: 'Federal',
    judges: ['Chief Justice Warren', 'Justice Black', 'Justice Reed', 'Justice Frankfurter', 'Justice Douglas', 'Justice Jackson', 'Justice Burton', 'Justice Clark', 'Justice Minton'],
    docketNumber: '1',
    status: 'good',
    statusLabel: 'Good Law',
    practiceAreas: ['Constitutional Law', 'Civil Rights', 'Equal Protection', 'Education Law'],
    headnotes: [
      'Segregation of children in public schools solely on the basis of race, even though physical facilities and other tangible factors may be equal, deprives the children of the minority group of equal educational opportunities.',
      'The "separate but equal" doctrine announced in Plessy v. Ferguson has no place in the field of public education.',
      'In the field of public education, the doctrine of "separate but equal" is unconstitutional.',
    ],
    holdings: [
      'Racial segregation in public schools violates the Equal Protection Clause of the Fourteenth Amendment.',
      'The doctrine of "separate but equal" has no place in public education.',
    ],
    excerpt: 'We conclude that in the field of public education the doctrine of "separate but equal" has no place. Separate educational facilities are inherently unequal. Therefore, we hold that the plaintiffs and others similarly situated for whom the actions have been brought are, by reason of the segregation complained of, deprived of the equal protection of the laws guaranteed by the Fourteenth Amendment.',
    fullText: [
      {
        id: 's1',
        heading: 'OPINION OF THE COURT',
        content: 'Chief Justice Warren delivered the opinion of the Court.\n\nThese cases come to us from the States of Kansas, South Carolina, Virginia, and Delaware. They are premised on different facts and different local conditions, but a common legal question justifies their consideration together in this consolidated opinion.',
      },
      {
        id: 's2',
        heading: 'I',
        content: 'In each of the cases, minors of the Negro race, through their legal representatives, seek the aid of the courts in obtaining admission to the public schools of their community on a nonsegregated basis. In each instance, they had been denied admission to schools attended by white children under laws requiring or permitting segregation according to race. This segregation was alleged to deprive the plaintiffs of the equal protection of the laws under the Fourteenth Amendment.',
      },
      {
        id: 's3',
        heading: 'II',
        content: 'We come then to the question presented: Does segregation of children in public schools solely on the basis of race, even though the physical facilities and other "tangible" factors may be equal, deprive the children of the minority group of equal educational opportunities? We believe that it does.\n\nTo separate them from others of similar age and qualifications solely because of their race generates a feeling of inferiority as to their status in the community that may affect their hearts and minds in a way unlikely ever to be undone.',
      },
      {
        id: 's4',
        heading: 'CONCLUSION',
        content: 'We conclude that in the field of public education the doctrine of "separate but equal" has no place. Separate educational facilities are inherently unequal. Therefore, we hold that the plaintiffs and others similarly situated for whom the actions have been brought are, by reason of the segregation complained of, deprived of the equal protection of the laws guaranteed by the Fourteenth Amendment. This disposition makes unnecessary any discussion whether such segregation also violates the Due Process Clause of the Fourteenth Amendment.',
      },
    ],
    citedBy: [
      {
        id: 'parents',
        citation: '551 U.S. 701 (2007)',
        shortName: 'Parents Involved in Community Schools v. Seattle School Dist. No. 1',
        court: 'Supreme Court of the United States',
        year: 2007,
        treatment: 'follows',
        snippet: 'Brown v. Board of Education and the constitutional guarantee of equal protection are at the heart of this case...',
      },
    ],
    cites: ['163 U.S. 537 (1896)', '339 U.S. 629 (1950)'],
    snippet: 'Landmark ruling declaring racial segregation in public schools unconstitutional, overruling Plessy v. Ferguson\'s "separate but equal" doctrine.',
    relevanceScore: 88,
  },
  {
    id: 'chevron',
    citation: '467 U.S. 837 (1984)',
    shortName: 'Chevron U.S.A., Inc. v. NRDC',
    fullName: 'Chevron U.S.A., Inc. v. Natural Resources Defense Council, Inc.',
    court: 'Supreme Court of the United States',
    date: 'June 25, 1984',
    year: 1984,
    jurisdiction: 'Federal',
    judges: ['Justice Stevens', 'Chief Justice Burger', 'Justice Brennan', 'Justice White', 'Justice Blackmun', 'Justice Powell', 'Justice Rehnquist', 'Justice O\'Connor'],
    docketNumber: '82-1005',
    status: 'bad',
    statusLabel: 'Overruled',
    practiceAreas: ['Administrative Law', 'Environmental Law', 'Statutory Interpretation'],
    headnotes: [
      'When a court reviews an agency\'s construction of the statute which it administers, it is confronted with two questions.',
      'If Congress has explicitly left a gap for the agency to fill, there is an express delegation of authority to the agency to elucidate a specific provision of the statute by regulation.',
      'A court may not substitute its own construction of a statutory provision for a reasonable interpretation made by the administrator of an agency.',
    ],
    holdings: [
      'Courts must defer to an agency\'s reasonable interpretation of ambiguous statutes that the agency administers.',
      'The "Chevron two-step": First, whether Congress has directly spoken to the precise question at issue; Second, whether the agency\'s interpretation is based on a permissible construction of the statute.',
    ],
    excerpt: 'When a court reviews an agency\'s construction of the statute which it administers, it is confronted with two questions. First, always, is the question whether Congress has directly spoken to the precise question at issue. If the intent of Congress is clear, that is the end of the matter.',
    fullText: [
      {
        id: 's1',
        heading: 'OPINION OF THE COURT',
        content: 'Justice Stevens delivered the opinion of the Court.\n\nIn the Clean Air Act Amendments of 1977, Congress enacted certain requirements applicable to States that had not achieved the national air quality standards established by the Environmental Protection Agency (EPA) pursuant to earlier legislation. The amended Clean Air Act required these "nonattainment" States to establish a permit program regulating "new or modified major stationary sources" of air pollution.',
      },
      {
        id: 's2',
        heading: 'II',
        content: 'When a court reviews an agency\'s construction of the statute which it administers, it is confronted with two questions. First, always, is the question whether Congress has directly spoken to the precise question at issue. If the intent of Congress is clear, that is the end of the matter; for the court, as well as the agency, must give effect to the unambiguously expressed intent of Congress. If, however, the court determines Congress has not directly addressed the precise question at issue, the court does not simply impose its own construction on the statute, as would be necessary in the absence of an administrative interpretation.',
      },
    ],
    citedBy: [
      {
        id: 'loper',
        citation: '603 U.S. ___ (2024)',
        shortName: 'Loper Bright Enterprises v. Raimondo',
        court: 'Supreme Court of the United States',
        year: 2024,
        treatment: 'overrules',
        snippet: 'Chevron is overruled. Courts must exercise their own independent judgment in determining the meaning of statutes.',
      },
    ],
    cites: ['467 U.S. 837 (1984)'],
    snippet: 'NOTE: Overruled by Loper Bright (2024). Established the "Chevron deference" doctrine requiring courts to defer to agencies\' reasonable statutory interpretations.',
    relevanceScore: 85,
  },
  {
    id: 'loper',
    citation: '603 U.S. ___ (2024)',
    shortName: 'Loper Bright Enterprises v. Raimondo',
    fullName: 'Loper Bright Enterprises v. Gina Raimondo, Secretary of Commerce',
    court: 'Supreme Court of the United States',
    date: 'June 28, 2024',
    year: 2024,
    jurisdiction: 'Federal',
    judges: ['Chief Justice Roberts', 'Justice Thomas', 'Justice Alito', 'Justice Gorsuch', 'Justice Kavanaugh', 'Justice Barrett'],
    docketNumber: '22-1219',
    status: 'good',
    statusLabel: 'Good Law',
    practiceAreas: ['Administrative Law', 'Statutory Interpretation', 'Separation of Powers'],
    headnotes: [
      'The Administrative Procedure Act requires courts to exercise their own judgment in determining the meaning of statutes.',
      'Chevron U.S.A. Inc. v. Natural Resources Defense Council, Inc. is overruled.',
      'Courts need not and under the APA may not defer to an agency interpretation of the law simply because a statute is ambiguous.',
    ],
    holdings: [
      'Chevron U.S.A., Inc. v. NRDC is overruled.',
      'Courts must exercise independent judgment in determining the meaning of statutes, including those administered by agencies.',
      'The APA requires that courts, not agencies, decide all relevant questions of law arising on review of agency action.',
    ],
    excerpt: 'The Administrative Procedure Act requires courts to exercise their own judgment in determining the meaning of statutes, including those administered by agencies. Courts may not defer to an agency interpretation of the law simply because a statute is ambiguous.',
    fullText: [
      {
        id: 's1',
        heading: 'OPINION OF THE COURT',
        content: 'Chief Justice Roberts delivered the opinion of the Court.\n\nThe question in these cases is whether a court reviewing agency action must defer to the agency\'s interpretation of the ambiguous statute the agency administers. In Chevron U.S.A. Inc. v. Natural Resources Defense Council, Inc., 467 U.S. 837 (1984), this Court held that when the statute an agency administers is ambiguous on a particular question, the agency can provide the answer, so long as its interpretation is "reasonable." We granted certiorari in these cases to decide whether to overrule Chevron.',
      },
      {
        id: 's2',
        heading: 'II',
        content: 'Chevron is overruled. Courts must exercise their own independent judgment in determining the meaning of statutes, as the APA requires. Careful attention to the judgment of the Executive Branch may help inform that inquiry. And when a particular statute delegates authority to an agency consistent with constitutional limits, courts must respect the delegation, while ensuring that the agency acts within it. But courts need not and under the APA may not defer to an agency interpretation of the law simply because a statute is ambiguous.',
      },
    ],
    citedBy: [],
    cites: ['467 U.S. 837 (1984)', '5 U.S.C. § 706'],
    snippet: 'Landmark 2024 decision overruling Chevron deference—courts must now independently interpret ambiguous statutes rather than deferring to agency interpretations.',
    relevanceScore: 94,
  },
  {
    id: 'erie',
    citation: '304 U.S. 64 (1938)',
    shortName: 'Erie Railroad Co. v. Tompkins',
    fullName: 'Erie Railroad Company v. Harry J. Tompkins',
    court: 'Supreme Court of the United States',
    date: 'April 25, 1938',
    year: 1938,
    jurisdiction: 'Federal',
    judges: ['Justice Brandeis', 'Chief Justice Hughes', 'Justice Stone', 'Justice Cardozo', 'Justice Reed'],
    docketNumber: '367',
    status: 'good',
    statusLabel: 'Good Law',
    practiceAreas: ['Civil Procedure', 'Federal Courts', 'Conflict of Laws'],
    headnotes: [
      'Except in matters governed by the Federal Constitution or by Acts of Congress, the law to be applied in any case is the law of the State.',
      'There is no federal general common law.',
      'Swift v. Tyson is overruled.',
    ],
    holdings: [
      'Federal courts sitting in diversity must apply the substantive law of the state in which they sit, including state common law.',
      'There is no federal general common law—Congress has no power to declare substantive rules of common law applicable in a state.',
    ],
    excerpt: 'Except in matters governed by the Federal Constitution or by Acts of Congress, the law to be applied in any case is the law of the State. And whether the law of the State shall be declared by its Legislature in a statute or by its highest court in a decision is not a matter of federal concern.',
    fullText: [
      {
        id: 's1',
        heading: 'OPINION OF THE COURT',
        content: 'Justice Brandeis delivered the opinion of the Court.\n\nThe question for decision is whether the oft-challenged doctrine of Swift v. Tyson shall now be disapproved.',
      },
      {
        id: 's2',
        heading: 'II',
        content: 'Except in matters governed by the Federal Constitution or by Acts of Congress, the law to be applied in any case is the law of the State. And whether the law of the State shall be declared by its Legislature in a statute or by its highest court in a decision is not a matter of federal concern. There is no federal general common law. Congress has no power to declare substantive rules of common law applicable in a state whether they be local in their nature or "general," be they commercial law or a part of the law of torts. And no clause in the Constitution purports to confer such a power upon the federal courts.',
      },
    ],
    citedBy: [
      {
        id: 'klaxon',
        citation: '313 U.S. 487 (1941)',
        shortName: 'Klaxon Co. v. Stentor Electric Mfg. Co.',
        court: 'Supreme Court of the United States',
        year: 1941,
        treatment: 'follows',
        snippet: 'The conflict of laws rules to be applied by the federal court in Delaware must conform to those prevailing in Delaware\'s state courts...',
      },
    ],
    cites: ['41 U.S. 1 (1842)'],
    snippet: 'Foundational diversity jurisdiction ruling establishing that federal courts must apply state substantive law, eliminating federal general common law.',
    relevanceScore: 87,
  },
];

export const RESEARCH_ANSWERS = [
  {
    query: 'What is the pleading standard for federal civil complaints?',
    answer: `Under **Bell Atlantic Corp. v. Twombly**, 550 U.S. 544 (2007), and **Ashcroft v. Iqbal**, 556 U.S. 662 (2009), the federal pleading standard requires that a complaint contain sufficient factual matter, accepted as true, to "state a claim to relief that is **plausible on its face**."

The Supreme Court in *Iqbal* articulated a **two-pronged analysis**:

1. **Disregard legal conclusions**: Courts are not bound to accept as true legal conclusions couched as factual allegations. "Threadbare recitals of the elements of a cause of action, supported by mere conclusory statements, do not suffice."

2. **Assess plausibility**: The court must determine whether the remaining factual allegations plausibly give rise to an entitlement to relief. This is "a context-specific task that requires the reviewing court to draw on its judicial experience and common sense."

This *Twombly/Iqbal* standard effectively retired the old *Conley v. Gibson* formulation that a complaint should not be dismissed "unless it appears beyond doubt that the plaintiff can prove no set of facts in support of his claim."

**Practical implications**: Plaintiffs must allege specific, non-conclusory facts supporting each element of their claim. The plausibility standard falls between "mere possibility" (insufficient) and "probability" (not required).`,
    sources: ['twombly', 'iqbal'],
    followUps: [
      'How does the plausibility standard apply to antitrust claims specifically?',
      'What constitutes a "conclusory" allegation under Iqbal?',
      'How have circuit courts applied Twombly/Iqbal to § 1983 claims?',
    ],
  },
  {
    query: 'What rights must police advise suspects of before interrogation?',
    answer: `Under **Miranda v. Arizona**, 384 U.S. 436 (1966), before conducting a **custodial interrogation**, law enforcement must advise suspects of the following rights:

1. **Right to remain silent** — The suspect has the right to remain silent and is not required to answer questions.
2. **Warning that statements may be used** — Any statement made may be used against the suspect in a court of law.
3. **Right to counsel** — The suspect has the right to have an attorney present during questioning.
4. **Right to appointed counsel** — If the suspect cannot afford an attorney, one will be appointed prior to questioning.

**Triggering conditions**: Miranda warnings are required only when there is both:
- **Custody** (formal arrest or restraint on freedom equivalent to arrest), *and*
- **Interrogation** (express questioning or its functional equivalent)

**Waiver**: A suspect may waive these rights if the waiver is made **voluntarily, knowingly, and intelligently**. Under *Berghuis v. Thompkins*, 560 U.S. 370 (2010), an uncoerced statement made after receiving Miranda warnings can constitute an implied waiver.

**Consequences of violation**: Statements obtained in violation of Miranda are generally inadmissible in the prosecution's case-in-chief, though they may be used for impeachment purposes (*Harris v. New York*).`,
    sources: ['miranda'],
    followUps: [
      'When does a police encounter become "custodial" for Miranda purposes?',
      'What are the exceptions to the Miranda exclusionary rule?',
      'How does Miranda apply to juvenile suspects?',
    ],
  },
];

export const SAMPLE_QUERIES = [
  'plausibility pleading standard Rule 12(b)(6)',
  'Miranda warnings custodial interrogation waiver',
  'Chevron deference administrative agency overruled',
  'Erie doctrine diversity jurisdiction state law',
  'equal protection segregation Fourteenth Amendment',
  'motion to dismiss failure to state a claim',
  'Fourth Amendment unreasonable search and seizure',
  'personal jurisdiction minimum contacts due process',
];

// ─── Tennessee Authorities ─────────────────────────────────────────────────────
export const TN_CASES = [
  {
    id: 'cranston',
    citation: '106 S.W.3d 641 (Tenn. 2003)',
    shortName: 'Cranston v. Combs',
    fullName: 'Cranston v. Combs',
    court: 'Tennessee Supreme Court',
    date: '2003', year: 2003,
    jurisdiction: 'Tennessee',
    status: 'good' as const, statusLabel: 'Good Law',
    practiceAreas: ['Family Law', 'Custody Modification'],
    holdings: [
      'Custody modification requires two-part showing: (1) material change in circumstances since prior decree; (2) modification is in the child\'s best interest.',
    ],
    excerpt: 'A party seeking to modify a custody arrangement must demonstrate both that a material change in circumstances has occurred since the entry of the original custody decree, and that the proposed modification would be in the best interest of the child.',
    snippet: 'Controlling TN authority — two-part material change test for custody modification.',
    headnotes: ['Material change must be substantial, unanticipated.', 'Change must affect the child\'s welfare.'],
    fullText: [{ id: 's1', heading: 'OPINION', content: 'The Tennessee Supreme Court held that modification of a custody arrangement requires a threshold showing of a material change in circumstances. This two-part test requires: first, that a material change has occurred since entry of the original decree; second, that the proposed modification serves the child\'s best interest.' }],
    citedBy: [], cites: [], docketNumber: '', judges: [],
  },
  {
    id: 'kissinger',
    citation: 'No. M2023-00481-COA-R3-CV (Tenn. Ct. App. 2024)',
    shortName: 'Kissinger v. Kissinger',
    fullName: 'Kissinger v. Kissinger',
    court: 'Tennessee Court of Appeals, Middle Section',
    date: '2024', year: 2024,
    jurisdiction: 'Tennessee',
    status: 'good' as const, statusLabel: 'Good Law',
    practiceAreas: ['Family Law', 'Orders of Protection'],
    holdings: [
      'Order of protection extension vacated where petition was not filed before expiration of original order as required by T.C.A. § 36-3-605(b).',
      'Nunc pro tunc entry cannot cure a jurisdictional defect in OP extension proceedings.',
    ],
    excerpt: 'The trial court lacked authority to extend the order of protection because the petition for extension was not filed before the expiration of the original order, as expressly required by T.C.A. § 36-3-605(b).',
    snippet: 'Recent authority vacating OP extensions entered after original order expired — procedural filing requirement is jurisdictional.',
    headnotes: ['T.C.A. § 36-3-605(b) requires petition filed before OP expiration.', 'Post-expiration nunc pro tunc entry does not cure defect.'],
    fullText: [{ id: 's1', heading: 'OPINION', content: 'Tennessee Code Annotated § 36-3-605(b) plainly requires that a petition for extension of an order of protection be filed before the expiration of the original order. The trial court\'s attempt to cure this defect through a nunc pro tunc order entered 254 days after expiration is ineffective. The order is vacated.' }],
    citedBy: [], cites: ['36-3-605'], docketNumber: 'M2023-00481-COA-R3-CV', judges: [],
  },
  {
    id: 'kawatra',
    citation: '182 S.W.3d 800 (Tenn. Ct. App. 2005)',
    shortName: 'Kawatra v. Kawatra',
    fullName: 'Kawatra v. Kawatra',
    court: 'Tennessee Court of Appeals',
    date: '2005', year: 2005,
    jurisdiction: 'Tennessee',
    status: 'good' as const, statusLabel: 'Good Law',
    practiceAreas: ['Family Law', 'Parental Relocation'],
    holdings: ['T.C.A. § 36-6-108 provides the governing framework for parental relocation disputes.', 'Relocating parent with majority parenting time may relocate absent opposition showing harm.'],
    excerpt: 'Under T.C.A. § 36-6-108, the framework for analyzing parental relocation depends on which parent has the greater amount of parenting time with the child.',
    snippet: 'Leading TN authority on parental relocation framework under T.C.A. § 36-6-108.',
    headnotes: [], fullText: [], citedBy: [], cites: [], docketNumber: '', judges: [],
  },
];

export const ALL_CASES = [...CASES, ...TN_CASES];
