export const STATE_JURISDICTIONS = [
  'Alabama','Alaska','Arizona','Arkansas','California','Colorado','Connecticut',
  'Dakota Territory','Delaware','District of Columbia','Florida','Georgia','Guam',
  'Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana',
  'Maine','Maryland','Massachusetts','Michigan','Minnesota','Mississippi','Missouri',
  'Montana','Nebraska','Nevada','New Hampshire','New Jersey','New Mexico','New York',
  'North Carolina','North Dakota','Ohio','Oklahoma','Oregon','Pennsylvania',
  'Rhode Island','South Carolina','South Dakota','Tennessee','Texas','Utah',
  'Vermont','Virginia','Washington','West Virginia','Wisconsin','Wyoming',
];

export const FEDERAL_CIRCUITS = [
  'U.S. Supreme Court',
  '1st Circuit',
  '2nd Circuit',
  '3rd Circuit',
  '4th Circuit',
  '5th Circuit',
  '6th Circuit',
  '7th Circuit',
  '8th Circuit',
  '9th Circuit',
  '10th Circuit',
  '11th Circuit',
  'D.C. Circuit',
  'Federal Circuit',
];

export const OTHER_FEDERAL = [
  'Tax Court',
  'Military',
  'Tribal',
  'Administrative & Other',
];

export const JURISDICTION_PRESETS = {
  TN_DEFAULT: {
    label: 'Tennessee (Default)',
    state: ['Tennessee'],
    federal: ['6th Circuit', 'U.S. Supreme Court'],
    other: [],
    display: 'Tennessee · 6th Cir.',
  },
  AL_DEFAULT: {
    label: 'Alabama',
    state: ['Alabama'],
    federal: ['11th Circuit', 'U.S. Supreme Court'],
    other: [],
    display: 'Alabama · 11th Cir.',
  },
  FEDERAL_ALL: {
    label: 'All Federal',
    state: [],
    federal: [...FEDERAL_CIRCUITS],
    other: [],
    display: 'All Federal Courts',
  },
};
