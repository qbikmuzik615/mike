// ─── App Views ────────────────────────────────────────────────────────────────
export type View = 'home' | 'chat' | 'draft' | 'analyze' | 'orchestrate' | 'search' | 'case';
export type AIMode = 'chat' | 'draft' | 'analyze' | 'orchestrate';

// ─── Jurisdiction ──────────────────────────────────────────────────────────────
export interface JurisdictionSelection {
  state: string[];
  federal: string[];
  other: string[];
}

// ─── Case Law ─────────────────────────────────────────────────────────────────
export interface Case {
  id: string;
  citation: string;
  shortName: string;
  fullName: string;
  court: string;
  date: string;
  year: number;
  jurisdiction: string;
  judges?: string[];
  docketNumber?: string;
  status: 'good' | 'bad' | 'caution' | 'neutral';
  statusLabel: string;
  headnotes?: string[];
  holdings: string[];
  excerpt: string;
  fullText: Section[];
  citedBy: CitingCase[];
  cites: string[];
  practiceAreas: string[];
  relevanceScore?: number;
  snippet?: string;
}

export interface Section {
  id: string;
  heading?: string;
  content: string;
  highlights?: Highlight[];
}

export interface Highlight {
  start: number;
  end: number;
  text: string;
  note?: string;
}

export interface CitingCase {
  id: string;
  citation: string;
  shortName: string;
  court: string;
  year: number;
  treatment: 'follows' | 'distinguishes' | 'criticizes' | 'overrules' | 'explains';
  snippet: string;
}

// ─── Research / Chat ───────────────────────────────────────────────────────────
export interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export interface Thread {
  id: number;
  title: string;
  mode: AIMode;
  messages: Message[];
  jurisdiction?: string;
  createdAt: Date;
}

export interface ResearchAnswer {
  query: string;
  answer: string;
  sources: string[];
  followUps: string[];
}

// ─── Agent Framework ───────────────────────────────────────────────────────────
export interface Agent {
  id: string;
  trigger: string;
  name: string;
  icon: string;
  color: string;
  expertise: string;
  jargon: string[];
  deliverable: string;
  integrationContract: string;
  description: string;
}

export interface Phase {
  id: number;
  phase: string;
  title: string;
  subtitle: string;
  icon: string;
  color: string;
  bgColor: string;
  borderColor: string;
  leadAgents: string[];
  collaboratingAgents: string[];
  steps: PhaseStep[];
  deliverables: string[];
  qualityGate: string;
}

export interface PhaseStep {
  actor: string;
  action: string;
  output?: string;
  code?: string;
  language?: string;
  note?: string;
}

export interface QACheck {
  id: number;
  requirement: string;
  adherence: 'YES' | 'PARTIAL' | 'NO';
  score: number;
  reasoning: string;
  enhancement: string;
}

export interface Module {
  id: number;
  name: string;
  icon: string;
  color: string;
  description: string;
  features: string[];
  techStack: string[];
}

export interface CollabQuestion {
  id: number;
  category: string;
  question: string;
  icon: string;
  purpose: string;
}

// ─── Saved Items ───────────────────────────────────────────────────────────────
export interface SavedItem {
  id: string;
  type: 'case' | 'query';
  caseId?: string;
  query?: string;
  savedAt: Date;
  notes?: string;
}
