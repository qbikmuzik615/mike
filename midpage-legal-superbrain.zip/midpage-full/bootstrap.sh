#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# midpage-legal-superbrain — bootstrap.sh
# Run ONCE after cloning / after downloading the zip.
# Sets up git, pushes to GitHub, and primes Claude Code.
# ─────────────────────────────────────────────────────────────────────────────
set -e

REPO_NAME="midpage-legal-superbrain"
BRANCH="main"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   midpage · Legal Super-Brain v11.0 — Bootstrap     ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ── 1. Check prerequisites ────────────────────────────────────────────────────
command -v git    >/dev/null 2>&1 || { echo "❌  git not found. Install git first."; exit 1; }
command -v node   >/dev/null 2>&1 || { echo "❌  node not found. Install Node 20+."; exit 1; }
command -v npm    >/dev/null 2>&1 || { echo "❌  npm not found."; exit 1; }

echo "✅  Prerequisites OK"

# ── 2. npm install ────────────────────────────────────────────────────────────
echo ""
echo "📦  Installing dependencies..."
npm install
echo "✅  node_modules installed"

# ── 3. .env.local ─────────────────────────────────────────────────────────────
if [ ! -f .env.local ]; then
  echo ""
  echo "🔑  Creating .env.local..."
  read -p "   Paste your Anthropic API key (sk-ant-...): " API_KEY
  echo "VITE_ANTHROPIC_API_KEY=${API_KEY}" > .env.local
  echo "✅  .env.local written (git-ignored)"
else
  echo "✅  .env.local already exists — skipping"
fi

# ── 4. Git init ───────────────────────────────────────────────────────────────
echo ""
echo "🗂   Initializing git repo..."
if [ ! -d .git ]; then
  git init
  git checkout -b ${BRANCH}
fi

git add -A
git commit -m "feat: initial commit — midpage Legal Super-Brain v11.0

- 5 AI modes: Chat / Draft / Analyze / Orchestrate / Search
- Full Legal Super-Brain v11.0 system prompts embedded
- Anthropic claude-sonnet streaming (SSE)
- Jurisdiction selector (50 states + 14 circuits)
- 6-agent Digital Software Agency team
- TN/AL jurisdiction defaults + case database
- Pro Se mode with Certificate of Service
- CLAUDE.md configured for Claude Code workflows"

echo "✅  Initial commit done"

# ── 5. GitHub remote ──────────────────────────────────────────────────────────
echo ""
echo "🐙  GitHub setup"
echo "   Option A — GitHub CLI (gh):"
echo "     gh repo create ${REPO_NAME} --private --source=. --remote=origin --push"
echo ""
echo "   Option B — Manual:"
echo "     1. Go to https://github.com/new"
echo "     2. Create repo named: ${REPO_NAME}"
echo "     3. Run:"
echo "        git remote add origin https://github.com/YOUR_USERNAME/${REPO_NAME}.git"
echo "        git push -u origin ${BRANCH}"
echo ""
read -p "   Do you have the GitHub CLI (gh) installed? [y/N] " USE_GH

if [[ "$USE_GH" =~ ^[Yy]$ ]]; then
  gh repo create ${REPO_NAME} --private --source=. --remote=origin --push
  echo "✅  Repo created and pushed via gh"
else
  read -p "   Enter your GitHub username: " GH_USER
  echo ""
  echo "   Create the repo at: https://github.com/new (name: ${REPO_NAME})"
  read -p "   Press Enter when done..."
  git remote add origin "https://github.com/${GH_USER}/${REPO_NAME}.git"
  git push -u origin ${BRANCH}
  echo "✅  Pushed to https://github.com/${GH_USER}/${REPO_NAME}"
fi

# ── 6. GitHub Secrets reminder ────────────────────────────────────────────────
echo ""
echo "🔐  Add these GitHub Secrets for CI/CD:"
echo "    Settings → Secrets and variables → Actions → New repository secret"
echo ""
echo "    VITE_ANTHROPIC_API_KEY   ← your Anthropic key"
echo "    VERCEL_TOKEN             ← from vercel.com/account/tokens"
echo "    VERCEL_ORG_ID            ← from vercel.com/account"
echo "    VERCEL_PROJECT_ID        ← after first vercel deploy"
echo ""

# ── 7. Claude Code ────────────────────────────────────────────────────────────
echo "🤖  Claude Code"
echo ""
command -v claude >/dev/null 2>&1 && CLAUDE_INSTALLED=true || CLAUDE_INSTALLED=false

if [ "$CLAUDE_INSTALLED" = false ]; then
  echo "   Installing Claude Code..."
  npm install -g @anthropic-ai/claude-code
  echo "✅  Claude Code installed"
else
  echo "✅  Claude Code already installed"
fi

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║                   BOOTSTRAP COMPLETE                ║"
echo "╠══════════════════════════════════════════════════════╣"
echo "║                                                      ║"
echo "║  Start dev server:    npm run dev                    ║"
echo "║  Open Claude Code:    claude                         ║"
echo "║                                                      ║"
echo "║  First Claude Code prompts to try:                   ║"
echo "║  > Run the dev server and fix any TypeScript errors  ║"
echo "║  > Add a HomePage component with hero + examples     ║"
echo "║  > Wire SearchPage to ALL_CASES from cases.ts        ║"
echo "║                                                      ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
